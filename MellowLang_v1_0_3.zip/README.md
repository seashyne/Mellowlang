# MellowLang v1.0.3

MellowLang คือ **Sandbox Scripting Language/Engine** (โฟกัส game/AI) รองรับไฟล์สคริปต์:
- `.mellow` (แนะนำ)
- `.fds` (event-driven)
- `.frinds` (legacy)

## Run (dev)
```bash
python -m mellowlang run examples/hello.mellow
```

## CLI
```bash
mellow --version
mellow run examples/loops.mellow
mellow check examples/loops.mellow
mellow fmt -w examples/hello.mellow
mellow modules
```

## Docs
- `docs/MELLOWLANG_User_Manual.md`
- `docs/RELEASE_NOTES_v1_0_1.md`
