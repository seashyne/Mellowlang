from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Any

from .legacy import Compiler as _LegacyCompiler  # legacy implementation (bytecode compiler)

@dataclass(frozen=True)
class CompiledProgram:
    """A compiled MellowLang program.

    Stable API between CLI ↔ Compiler ↔ VM (v1.0.3+).
    """
    bytecode: List[tuple]
    filename: Optional[str] = None
    source_lines: Optional[List[str]] = None

class Compiler:
    """Stable compiler facade.

    Contract:
      - compile(source, filename=None) -> CompiledProgram
    """

    def __init__(self) -> None:
        self._impl = _LegacyCompiler()

    def compile(self, source: str, *, filename: str | None = None) -> CompiledProgram:
        # legacy compiler expects list[str] (lines without trailing newlines are ok)
        lines = source.splitlines()
        bytecode = self._impl.compile(lines)
        return CompiledProgram(bytecode=bytecode, filename=filename, source_lines=source.splitlines())
