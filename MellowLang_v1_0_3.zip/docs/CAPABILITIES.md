# MellowLang Capabilities (v1.0.3)

## Language
- Basic types: number, string, bool, none/null
- Variables: `keep x = ...`, assignment `x = ...`
- Conditions: `check/also/else`
- Loops: while, for-range, foreach styles (see Syntax Reference)
- Skills (functions): `skill name(args): ... return ...`
- Lists, maps, strings, math helpers (via allowlisted modules)

## Built-ins
- Output: `print(...)` (alias of `show(...)`)
- Input: `input(...)` (alias of `ask(...)`, sandbox gated)
- Random: `randi(a,b)`, `rand()` etc
- Determinism: `global_seed(n)` (runtime)

## Sandbox
- Allowlisted modules via `get("math")` / `import "math" as m`
- `input()` gated by `--allow-ask`
- `wait()` can be disabled by `--no-wait`

## Tooling
- CLI (legacy + modern, stable in v1.x)
- VS Code extension (syntax highlighting + basic LSP)
- Formatter: `mellow fmt`
