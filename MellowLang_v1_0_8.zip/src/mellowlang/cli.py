from __future__ import annotations

import argparse
import json
import re
import os
import shutil
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, List

from . import __version__
from .lint import lint_source, format_source
from .host.modules import MODULE_ALLOWLIST
from .compiler import Compiler, CompiledProgram
from .vm import MellowVM, RunConfig


# ============================================================
# CLI policy (v1.0.7+)
# - Legacy UX stays supported.
# - Modern subcommands stay supported.
# - No breaking removals in v1.x (only additive).
# ============================================================

MODERN_CMDS = {"run", "check", "fmt", "init", "modules", "lsp", "help"}

def _start_lsp() -> int:
    from .lsp_server import start_lsp  # lazy import (pygls optional)
    return int(start_lsp() or 0)


def _supports_ansi() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.name != "nt":
        return True
    env = os.environ
    return any(k in env for k in ("WT_SESSION", "TERM", "ANSICON", "ConEmuANSI")) or (
        "vscode" in env.get("TERM_PROGRAM", "").lower()
    )


def _print_pretty_error(
    err: Exception,
    filename: str | None = None,
    source_lines: list[str] | None = None,
    *,
    use_color: bool | None = None,
) -> None:
    """
    Frinds-style error formatter:
      Error: <TYPE> at <file>:<line>:<col>
        <message>
        <code frame + caret>
    """
    msg = getattr(err, "message", None) or str(err)

    if use_color is None:
        use_color = _supports_ansi()

    if use_color:
        RED = "\033[31m"
        YELLOW = "\033[33m"
        DIM = "\033[2m"
        RESET = "\033[0m"
    else:
        RED = YELLOW = DIM = RESET = ""

    # ---- Pull structured fields if present (preferred) ----
    err_type = getattr(err, "error_type", None)
    line_no = getattr(err, "line_num", None)
    col = getattr(err, "col", None)
    fn = getattr(err, "filename", None) or filename

    # ---- Fallback: infer line/col from message (ParseError, etc.) ----
    snippet = None
    if line_no is None:
        m = re.search(r"\bline\s+(\d+)\b", msg)
        if m:
            line_no = int(m.group(1))
    if fn is None:
        # e.g. "RUNTIME at test.fds:46: division by zero"
        m = re.search(r"\bat\s+(.+?):(\d+)(?::(\d+))?\b", msg)
        if m:
            fn = m.group(1)
            if line_no is None:
                line_no = int(m.group(2))
            if m.group(3) and col is None:
                col = int(m.group(3))
    # snippet often appears after ":" in messages like "... at line 6: kee i"
    m = re.search(r"\bline\s+\d+\s*:\s*(.+)$", msg)
    if m:
        snippet = m.group(1).strip()

    if not err_type:
        # ParseError usually means SYNTAX, everything else ERROR
        err_type = "SYNTAX" if err.__class__.__name__ in ("ParseError",) else "ERROR"

    # Compute column from snippet if possible
    if source_lines and line_no and col is None and snippet:
        try:
            line_text = source_lines[int(line_no) - 1]
            idx = line_text.find(snippet)
            if idx >= 0:
                col = idx + 1
        except Exception:
            pass
    if col is None:
        col = 1

    # ---- Header (match Frinds look) ----
    loc = ""
    if fn and line_no:
        loc = f"{fn}:{line_no}:{col}"
    elif fn and line_no is None:
        loc = str(fn)
    elif line_no:
        loc = f"line {line_no}:{col}"

    print(f"{RED}Error:{RESET} {err_type}" + (f" at {loc}" if loc else ""))
    print(f"  {msg}")

    # ---- Call stack (if present) ----
    trace = getattr(err, "trace", None)
    if trace:
        print(f"{DIM}Call Stack:{RESET}")
        for fr in reversed(trace):
            nm = fr.get("name", "<frame>")
            ffn = fr.get("filename", fn) or "<script>"
            ln = fr.get("line")
            cc = fr.get("col")
            floc = ffn if ln is None else f"{ffn}:{ln}" + (f":{cc}" if cc else "")
            print(f"  at {nm} ({floc})")

    # ---- Code frame ----
    if not source_lines or not line_no:
        return
    try:
        ln = int(line_no)
    except Exception:
        return
    if ln < 1 or ln > len(source_lines):
        return

    i = ln - 1
    lo = max(0, i - 1)
    hi = min(len(source_lines) - 1, i + 1)
    for j in range(lo, hi + 1):
        prefix = ">" if j == i else " "
        print(f"{prefix} {j+1:3d} | {source_lines[j].rstrip()}")
        if j == i:
            caret_pos = max(1, min(int(col), len(source_lines[j]) + 1))
            print(f"    | {' '*(caret_pos-1)}{YELLOW}^{RESET}")


def _prog() -> str:
    base = os.path.basename(sys.argv[0]) or "mellow"
    return os.path.splitext(base)[0]

def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")

def _json_print(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))

def _build_legacy_parser() -> argparse.ArgumentParser:
    prog = _prog()
    p = argparse.ArgumentParser(
        prog=prog,
        formatter_class=argparse.RawTextHelpFormatter,
        description=f"""MellowLang {__version__}
Friendly scripting language (game / AI focused)

Legacy usage:
  {prog} <script.mellow> [options]

Modern usage:
  {prog} run <script>
  {prog} check <script>
  {prog} fmt [-w] [--check] <files...>
  {prog} init <dir> [--force]
  {prog} modules [--json]
  {prog} lsp
""",
    )

    p.add_argument("script", nargs="?", help="Path to .mellow script")

    # runtime flags (legacy-compatible)
    p.add_argument("--check", dest="check_only", action="store_true",
                  help="Only check syntax/lint; do not run")
    p.add_argument("--modules", dest="list_modules", action="store_true",
                  help="List allowed host modules (same as: modules)")
    p.add_argument("--json", action="store_true", help="Output machine-readable JSON")

    mx = p.add_mutually_exclusive_group()
    mx.add_argument("--record", dest="record_path", help="Record deterministic replay log (.jsonl)")
    mx.add_argument("--replay", dest="replay_path", help="Replay deterministic log (.jsonl)")

    p.add_argument("--seed", type=int, help="Per-script seed")
    p.add_argument("--global-seed", type=int, help="Global base seed")

    p.add_argument("--allow-ask", action="store_true", help="Enable input()/ask() in sandbox")
    p.add_argument("--no-wait", action="store_true", help="Disable wait() in sandbox")
    p.add_argument("--color", action="store_true", help="Force colored errors")
    p.add_argument("--no-color", action="store_true", help="Disable colored errors")

    # compatibility flags (kept, but no longer required)
    p.add_argument("--engine", action="store_true", help="(Compat) Ignored in v1.0.7+")
    p.add_argument("--legacy", action="store_true", help="(Compat) Ignored in v1.0.7+")
    p.add_argument("--emit", dest="emit_name", help="(Compat) Reserved for .fds workflows")
    p.add_argument("--emit-args", dest="emit_args_raw", help="(Compat) JSON array args for --emit")

    p.add_argument("--lsp", action="store_true", help="Start Language Server (stdio)")
    p.add_argument("--version", action="version", version=f"{prog} {__version__}")
    return p

def _build_modern_parser() -> argparse.ArgumentParser:
    prog = _prog()
    p = argparse.ArgumentParser(
        prog=prog,
        formatter_class=argparse.RawTextHelpFormatter,
        description=f"""MellowLang {__version__}

Modern commands:
  {prog} run <file>            Run a script
  {prog} check <file>          Lint / syntax check
  {prog} fmt <files...>        Format source
  {prog} init <dir>            Create a project
  {prog} modules [--json]      List allowed host modules
  {prog} lsp                   Start language server (stdio)
""",
    )
    p.add_argument("--version", action="version", version=f"{prog} {__version__}")

    sub = p.add_subparsers(dest="cmd")

    pr = sub.add_parser("run", help="Run a script")
    pr.add_argument("file")
    pr.add_argument("--json", action="store_true")
    pr.add_argument("--record", dest="record_path")
    pr.add_argument("--replay", dest="replay_path")
    pr.add_argument("--seed", type=int)
    pr.add_argument("--global-seed", type=int)
    pr.add_argument("--allow-ask", action="store_true")
    pr.add_argument("--no-wait", action="store_true")

    pc = sub.add_parser("check", help="Check a script")
    pc.add_argument("file")
    pc.add_argument("--json", action="store_true")

    pf = sub.add_parser("fmt", help="Format files")
    pf.add_argument("files", nargs="+")
    pf.add_argument("-w", "--write", action="store_true")
    pf.add_argument("--check", action="store_true")

    pi = sub.add_parser("init", help="Create project from template")
    pi.add_argument("dir")
    pi.add_argument("--force", action="store_true")

    pm = sub.add_parser("modules", help="List allowed host modules")
    pm.add_argument("--json", action="store_true")

    sub.add_parser("lsp", help="Start language server")
    sub.add_parser("help", help="Show help")

    return p

# ----------------------------
# Command handlers
# ----------------------------

def _cmd_modules(json_out: bool) -> int:
    if json_out:
        _json_print(MODULE_ALLOWLIST)
        return 0
    print("Allowed host modules:")
    for mod in sorted(MODULE_ALLOWLIST.keys()):
        print(f"  - {mod}")
    return 0

def _cmd_check(file: str, json_out: bool) -> int:
    """
    Check mode:
      - First, attempt to compile (catches SYNTAX errors with code frame)
      - Then, run lints; print code-frame per issue
    """
    p = Path(file)
    if not p.exists():
        err = {"ok": False, "error": f"file not found: {p}"}
        if json_out:
            _json_print(err)
        else:
            print(f"error: {err['error']}")
        return 2

    src = _read_text(p)
    lines = src.splitlines(True)

    # 1) Syntax check via compiler (best signal)
    try:
        Compiler().compile(src, filename=str(p))
    except Exception as e:
        if json_out:
            _json_print({"ok": False, "error": str(e)})
        else:
            _print_pretty_error(e, filename=str(p), source_lines=lines)
        return 1

    # 2) Lint/style issues (non-fatal but should be visible)
    issues = lint_source(src)
    if json_out:
        _json_print({
            "ok": len(issues) == 0,
            "file": str(p),
            "issues": [asdict(it) if hasattr(it, "__dict__") else {"message": str(it)} for it in issues],
        })
        return 0 if not issues else 1

    if not issues:
        print("✓ ok")
        return 0

    # Print code-frame per issue (Frinds-style)
    for it in issues:
        kind = getattr(it, "kind", "LINT").upper()
        msg = getattr(it, "message", str(it))
        ln = getattr(it, "line", None)
        col = getattr(it, "col", None)

        # fabricate an error-like object compatible with _print_pretty_error
        class _IssueErr(Exception):
            pass
        ee = _IssueErr(msg)
        setattr(ee, "error_type", kind)
        setattr(ee, "message", msg)
        setattr(ee, "filename", str(p))
        setattr(ee, "line_num", ln)
        setattr(ee, "col", col)
        _print_pretty_error(ee, filename=str(p), source_lines=lines)

    return 1
def _cmd_fmt(files: List[str], write: bool, check: bool) -> int:
    changed = 0
    for f in files:
        p = Path(f)
        if p.is_dir():
            for sub in p.rglob("*.mellow"):
                changed += _fmt_one(sub, write, check)
        else:
            changed += _fmt_one(p, write, check)
    return 0 if (not check or changed == 0) else 1

def _fmt_one(p: Path, write: bool, check: bool) -> int:
    if not p.exists():
        print(f"skip: {p} (not found)")
        return 0
    src = _read_text(p)
    out = format_source(src)
    if out == src:
        return 0
    if check:
        print(f"would format: {p}")
        return 1
    if write:
        p.write_text(out, encoding="utf-8")
        print(f"formatted: {p}")
        return 1
    sys.stdout.write(out)
    return 1

def _cmd_init(dest_dir: str, force: bool) -> int:
    dest = Path(dest_dir).resolve()
    template = Path(__file__).resolve().parents[2] / "project_template"
    if not template.exists():
        print("error: project_template not found.")
        return 2
    if dest.exists() and any(dest.iterdir()) and not force:
        print("error: destination not empty. Use --force.")
        return 2
    if dest.exists() and force:
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copytree(template, dest, dirs_exist_ok=True)
    print(f"✓ created project: {dest}")
    return 0

def _cmd_run(file: str, *, json_out: bool, record_path: str | None, replay_path: str | None,
             seed: int | None, global_seed: int | None, allow_ask: bool, no_wait: bool,
             color: bool, no_color: bool) -> int:
    p = Path(file)
    if not p.exists():
        err = {"ok": False, "error": f"file not found: {p}"}
        if json_out:
            _json_print(err)
        else:
            print(f"error: {err['error']}")
        return 2

    
    src = _read_text(p)

    # error color policy is currently handled by runtime; here we only ensure ANSI support isn't forced wrongly.
    # (kept for CLI compatibility)
    use_color = True if color else (False if no_color else None)

    try:
        comp = Compiler()
        program = comp.compile(src, filename=str(p))

        vm = MellowVM()
        cfg = RunConfig(
            seed=seed,
            global_seed=global_seed,
            record_path=record_path,
            replay_path=replay_path,
            allow_ask=allow_ask,
            allow_wait=not no_wait,
        )

        result = vm.run(program, config=cfg)
        if json_out:
            _json_print({"ok": True, "result": result})
        return 0
    except Exception as e:
        if json_out:
            _json_print({"ok": False, "error": str(e)})
        else:
            _print_pretty_error(e, filename=str(p), source_lines=src.splitlines(True), use_color=use_color)
        return 1
# ----------------------------
# Main
# ----------------------------

def main(argv: List[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    # mode selection
    if argv and argv[0] in MODERN_CMDS:
        p = _build_modern_parser()
        ns = p.parse_args(argv)
        cmd = ns.cmd
        if cmd in (None, "help"):
            p.print_help()
            return 0
        if cmd == "modules":
            return _cmd_modules(ns.json)
        if cmd == "check":
            return _cmd_check(ns.file, ns.json)
        if cmd == "fmt":
            return _cmd_fmt(ns.files, ns.write, ns.check)
        if cmd == "init":
            return _cmd_init(ns.dir, ns.force)
        if cmd == "lsp":
            return int(_start_lsp() or 0)
        if cmd == "run":
            return _cmd_run(
                ns.file,
                json_out=ns.json,
                record_path=getattr(ns, "record_path", None),
                replay_path=getattr(ns, "replay_path", None),
                seed=getattr(ns, "seed", None),
                global_seed=getattr(ns, "global_seed", None),
                allow_ask=getattr(ns, "allow_ask", False),
                no_wait=getattr(ns, "no_wait", False),
                color=False,
                no_color=False,
            )
        p.print_help()
        return 2

    # legacy mode
    p = _build_legacy_parser()
    ns = p.parse_args(argv)

    if getattr(ns, "lsp", False):
        return int(_start_lsp() or 0)

    if getattr(ns, "list_modules", False):
        return _cmd_modules(bool(ns.json))

    if not ns.script:
        p.print_help()
        return 2

    if getattr(ns, "check_only", False):
        return _cmd_check(ns.script, bool(ns.json))

    return _cmd_run(
        ns.script,
        json_out=bool(ns.json),
        record_path=getattr(ns, "record_path", None),
        replay_path=getattr(ns, "replay_path", None),
        seed=getattr(ns, "seed", None),
        global_seed=getattr(ns, "global_seed", None),
        allow_ask=getattr(ns, "allow_ask", False),
        no_wait=getattr(ns, "no_wait", False),
        color=getattr(ns, "color", False),
        no_color=getattr(ns, "no_color", False),
    )
