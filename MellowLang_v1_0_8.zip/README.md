# MellowLang

MellowLang is a **sandbox scripting language** focused on **games** and **AI behavior**.

- **Fast feedback**: friendly errors with `line:col`, code-frame, and caret (`^`)
- **Deterministic runs**: seeds + record/replay (great for debugging gameplay/AI)
- **Safe by default**: host allowlist + optional permissions (ask/wait/storage)
- **Modern syntax (recommended)**: `let/var`, `def`, `print`, `for/while` (Python-like)

> Status: **Public Alpha** (v1.0.x).  
> Policy: v1.x is **backwards-compatible** for CLI and core APIs (see `docs/POLICY_v1x.md`).

---

## Quick start (Windows)

### Option A: Portable ZIP (recommended)
1. Download the latest release ZIP.
2. Unzip anywhere.
3. Open a terminal in the folder and run:

```powershell
mellow examples\hello.mellow
mellow examples\loops.mellow
```

### Option B: Python (for contributors)
```powershell
python -m pip install -e .[dev]
mellow --version
mellow examples\hello.mellow
```

---

## Example

```mellow
let score = 0

def add(a, b):
    return a + b

for i in range(0, 6):
    score = add(score, i)

print(score)
```

Run it:
```powershell
mellow run my_script.mellow
```

---

## CLI (stable in v1.x)

Modern commands (recommended):
```bash
mellow run <file>
mellow check <file>
mellow fmt -w <files...>
mellow init <dir>
mellow modules --json
mellow lsp
```

Legacy mode (still supported):
```bash
mellow <file>
mellow <file> --check
```

---

## Storage & files (safe + explicit)

System base dir is **`mellow_saves/`**.

- Mellow **does not** create user subfolders automatically.
- If you want folders, create them explicitly:

```mellow
mkdir(".")            # create mellow_saves
mkdir("profiles")     # create mellow_saves/profiles

save_data("profiles/p1", {"xp": 10})
print(load_data("profiles/p1"))
```

File modes:
- text: `"r"`, `"w"`, `"a"`
- binary: `"rb"`, `"wb"`, `"ab"`

---

## VS Code
- Install the extension from the release `.vsix`:
  - Extensions → `...` → **Install from VSIX**
- Then open a `.mellow` file.

---

## Contributing
- Run tests:
```bash
python -m pip install -e .[dev]
pytest -q
```

---

## Docs
- Syntax reference: `docs/SYNTAX_REFERENCE.md`
- Style guide (recommended modern): `docs/STYLE_GUIDE.md`
- Stable checklist: `docs/STABLE_CHECKLIST.md`
- Compatibility policy: `docs/POLICY_v1x.md`

---

## License
MIT (see `LICENSE`)
