# Stable Checklist (Game + AI Ready)

This checklist describes the bar for **Stable** (target: v1.1+ / v2.0 depending on scope).

## Language core
- [ ] Grammar and block rules documented (indentation rules are explicit)
- [ ] Syntax reference complete + examples for every feature
- [ ] No crashes on invalid input (all errors are `MellowLangRuntimeError`)
- [ ] Deterministic mode documented (seed + replay)

## Error UX (must)
- [ ] SYNTAX errors include accurate `line:col` + code-frame + caret
- [ ] RUNTIME errors include accurate `line:col` + code-frame + caret
- [ ] Call stack shows user frames first (file + line + function)
- [ ] `mellow check` output matches `mellow run` formatting

## Tooling
- [ ] VS Code extension: syntax highlight + diagnostics + LSP basics
- [ ] Formatter (`mellow fmt`) is idempotent (running twice gives same output)
- [ ] Linter (`mellow check`) returns non-zero on issues

## Sandbox + permissions (game/mod safe)
- [ ] Default sandbox: no network, no arbitrary filesystem
- [ ] Explicit permissions/flags for: ask/input, wait/sleep, storage/files
- [ ] Path traversal protection (no `..`, no absolute escapes)

## Storage & files
- [ ] System base dir: `mellow_saves/`
- [ ] No auto-creation of user subfolders
- [ ] Atomic writes on save
- [ ] Clear file modes: r/w/a + rb/wb/ab

## Performance (game loop ready)
- [ ] Step budget / time budget options
- [ ] Profiler or timing hooks for scripts
- [ ] Stress test: 10k loop iterations without slowdown surprises

## Quality gates (required)
- [ ] Tests: parser + runtime + error formatting (>= 30 cases recommended)
- [ ] CI: tests run on push/PR (GitHub Actions)
- [ ] Releases: portable ZIP + VSIX (optional installer)

## Demos (make it real)
- [ ] Game demo: deterministic replay for gameplay logic
- [ ] AI demo: behavior/state machine or utility AI example
