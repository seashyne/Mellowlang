# MellowLang v1.0.4 Update

## Focus
This release improves developer experience around errors and checking:
- Frinds-style error formatting (header + code frame + caret).
- `mellow check` now prints the same code frame format instead of a plain list.

## CLI Stability
v1.x CLI is **locked**: existing flags/subcommands remain supported. New flags are additive only.
