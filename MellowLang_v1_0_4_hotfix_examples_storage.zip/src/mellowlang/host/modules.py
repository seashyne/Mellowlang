from __future__ import annotations

# Stable import path for module allowlist.
from .legacy import MODULE_ALLOWLIST

__all__ = ["MODULE_ALLOWLIST"]
