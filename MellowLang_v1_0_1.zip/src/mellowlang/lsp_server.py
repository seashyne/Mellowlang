"""
MellowLang LSP Server (minimal) - v1.0.1

Features:
- Diagnostics from mellowlang.lint.lint_source (syntax errors)
- Basic autocomplete keywords/builtins
"""

from __future__ import annotations

import re
import sys
from typing import List, Optional

from pygls.server import LanguageServer
from pygls.lsp.types import (
    CompletionItem,
    CompletionList,
    CompletionOptions,
    CompletionParams,
    Diagnostic,
    DiagnosticSeverity,
    DidChangeTextDocumentParams,
    DidOpenTextDocumentParams,
    InitializeParams,
    Position,
    Range,
    TextDocumentSyncKind,
)
from pygls.lsp.methods import (
    TEXT_DOCUMENT_DID_OPEN,
    TEXT_DOCUMENT_DID_CHANGE,
    TEXT_DOCUMENT_COMPLETION,
)

from mellowlang.lint import lint_source

LANG_ID = "mellow"

KEYWORDS = [
    "if", "else", "end",
    "loop", "while", "repeat", "until", "for", "in", "break", "continue",
    "and", "or", "not",
    "skill", "on", "emit", "catch", "try",
    "import",
    "vec", "vector", "vec2", "vec3", "vec4",
    "true", "false", "nil",
]

BUILTINS = [
    "print", "len", "type",
    "math", "time", "random",
]

def _extract_line_from_msg(msg: str) -> Optional[int]:
    m = re.search(r"line\s+(\d+)", msg)
    if not m:
        return None
    try:
        return int(m.group(1))
    except Exception:
        return None

def _mk_diag(msg: str, line0: int) -> Diagnostic:
    # underline whole line (best-effort)
    r = Range(
        start=Position(line=line0, character=0),
        end=Position(line=line0, character=9999),
    )
    return Diagnostic(range=r, message=msg, severity=DiagnosticSeverity.Error, source="mellow")

class MellowLangLanguageServer(LanguageServer):
    pass

server = MellowLangLanguageServer("mellowlang-lsp", "1.0.0")

@server.feature(TEXT_DOCUMENT_DID_OPEN)
def did_open(ls: MellowLangLanguageServer, params: DidOpenTextDocumentParams):
    _validate(ls, params.text_document.uri, params.text_document.text)

@server.feature(TEXT_DOCUMENT_DID_CHANGE)
def did_change(ls: MellowLangLanguageServer, params: DidChangeTextDocumentParams):
    text = params.content_changes[0].text
    _validate(ls, params.text_document.uri, text)

def _validate(ls: MellowLangLanguageServer, uri: str, text: str):
    issues = lint_source(text)
    diags: List[Diagnostic] = []
    for iss in issues:
        if iss.kind == "SYNTAX":
            line = _extract_line_from_msg(iss.message)
            if line is None:
                line0 = 0
            else:
                line0 = max(0, line - 1)
            diags.append(_mk_diag(iss.message, line0))
    ls.publish_diagnostics(uri, diags)

@server.feature(TEXT_DOCUMENT_COMPLETION, CompletionOptions(trigger_characters=[".", ":", "(", " "]))
def completions(ls: MellowLangLanguageServer, params: CompletionParams):
    items: List[CompletionItem] = []
    for kw in KEYWORDS:
        items.append(CompletionItem(label=kw, kind=14))  # Keyword
    for b in BUILTINS:
        items.append(CompletionItem(label=b, kind=3))    # Function/Module-ish
    return CompletionList(is_incomplete=False, items=items)

def start_lsp() -> int:
    # stdio mode
    server.start_io()
    return 0

if __name__ == "__main__":
    raise SystemExit(start_lsp())
