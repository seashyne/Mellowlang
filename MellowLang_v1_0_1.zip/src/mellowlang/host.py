# frinds/host.py
from __future__ import annotations
from dataclasses import dataclass
from .range_core import MellowLangRange
from typing import Any, Callable, Dict, List, Optional, Tuple

# Public allowlist for safe get()/import usage
MODULE_ALLOWLIST = {
        "math": {
            "abs": "std.math.abs", "min": "std.math.min", "max": "std.math.max",
            "floor": "std.math.floor", "ceil": "std.math.ceil", "round": "std.math.round",
            "sqrt": "std.math.sqrt", "pow": "std.math.pow",
            "sin": "std.math.sin", "cos": "std.math.cos", "tan": "std.math.tan",
            "atan2": "std.math.atan2", "clamp": "std.math.clamp", "lerp": "std.math.lerp",
            # vectors
            "vec2": "std.math.vec2", "vec3": "std.math.vec3",
            "vec": "std.math.vector", "vector": "std.math.vector",
            "vec_add": "std.math.vec_add", "vec_sub": "std.math.vec_sub", "vec_mul": "std.math.vec_mul",
            "vec_dot": "std.math.vec_dot", "vec_len": "std.math.vec_len", "vec_norm": "std.math.vec_norm",
            "vec_dist": "std.math.vec_dist",
            "vec_lerp": "std.math.vec_lerp", "vec_limit": "std.math.vec_limit",
            "vec_dim": "std.math.vec_dim", "vec_axis": "std.math.vec_axis",
            "pi": "std.math.pi",
        },
        "time": {
            "unix": "std.time.unix", "ms": "std.time.ms", "now": "std.time.now",
        },
        "list": {
            "push": "std.list.push", "pop": "std.list.pop", "len": "std.list.len",
            "insert": "std.list.insert", "remove": "std.list.remove", "has": "std.list.has",
            "sort": "std.list.sort",
        },
        "map": {
            "get": "std.map.get", "set": "std.map.set", "keys": "std.map.keys",
            "values": "std.map.values", "has": "std.map.has",
        },
        "string": {
            "len": "std.string.len", "lower": "std.string.lower", "upper": "std.string.upper",
            "trim": "std.string.trim", "replace": "std.string.replace", "find": "std.string.find",
            "split": "std.string.split", "join": "std.string.join",
        },
        "json": {
            "encode": "std.json.encode", "decode": "std.json.decode",
        },
    }


@dataclass
class HostFunction:
    name: str
    handler: Callable[[List[Any]], Any]
    cost: int = 1
    # Very light schema: min/max args + (optional) validator
    min_args: int = 0
    max_args: int = 99
    validator: Optional[Callable[[List[Any]], None]] = None

class HostRegistry:
    """Capability bridge registry (เหมือน Lua host functions แต่มี cost/budget)"""
    def __init__(self):
        self._funcs: Dict[str, HostFunction] = {}

    def register(self, func: HostFunction):
        self._funcs[func.name] = func

    def has(self, name: str) -> bool:
        return name in self._funcs

    def get_cost(self, name: str) -> int:
        return self._funcs[name].cost if name in self._funcs else 0

    def call(self, name: str, args: List[Any]) -> Any:
        if name not in self._funcs:
            raise RuntimeError(f"SANDBOX: unknown syscall '{name}'")
        fn = self._funcs[name]
        if not (fn.min_args <= len(args) <= fn.max_args):
            raise RuntimeError(f"SANDBOX: syscall '{name}' expects {fn.min_args}-{fn.max_args} args, got {len(args)}")
        if fn.validator:
            fn.validator(args)
        return fn.handler(args)

def default_host() -> HostRegistry:
    """Host ตัวอย่าง (ให้รันทดสอบได้ทันที)"""
    h = HostRegistry()
    h.register(HostFunction(
        name="sys.echo",
        handler=lambda a: a[0] if a else None,
        cost=1,
        min_args=0,
        max_args=1
    ))

    # ---------------- Module get/import helper ----------------
    # get("math") -> {"abs": "std.math.abs", ...}
    # Allows dynamic call(module["abs"], x) while still enforcing an allowlist.
    _module_cache: Dict[str, Dict[str, str]] = {}
    _MODULE_ALLOWLIST = MODULE_ALLOWLIST

    def _sys_get(args: List[Any]):
        name = str(args[0]) if args else ""
        name = name.strip().lower()
        if name not in _MODULE_ALLOWLIST:
            raise RuntimeError(f"sys.get: module not allowed: {name}")
        if name in _module_cache:
            return _module_cache[name]
        mod = dict(_MODULE_ALLOWLIST[name])
        _module_cache[name] = mod
        return mod

    h.register(HostFunction('sys.get', _sys_get, cost=1, min_args=1, max_args=1))
    # Example: clamp(number, lo, hi)

    # ----- stdlib (allowlist) -----
    import json as _json

    def _is_list(x):
        if not isinstance(x, list):
            raise RuntimeError('std.list: expected list')

    def _is_dict(x):
        if not isinstance(x, dict):
            raise RuntimeError('std.map: expected map')

    h.register(HostFunction(
        name='std.list.push',
        handler=lambda a: (a[0].append(a[1]) or a[0]) if (_is_list(a[0]) is None) else a[0],
        cost=1,
        min_args=2,
        max_args=2
    ))
    h.register(HostFunction(
        name='std.list.pop',
        handler=lambda a: (a[0].pop() if (_is_list(a[0]) is None) and a[0] else None),
        cost=1,
        min_args=1,
        max_args=1
    ))
    h.register(HostFunction(
        name='std.list.len',
        handler=lambda a: len(a[0]) if (_is_list(a[0]) is None) else 0,
        cost=1,
        min_args=1,
        max_args=1
    ))

    def _map_get(args):
        m, k = args[0], args[1]
        _is_dict(m)
        if len(args) == 3:
            return m.get(k, args[2])
        return m.get(k)
    h.register(HostFunction('std.map.get', _map_get, cost=1, min_args=2, max_args=3))

    def _map_set(args):
        m, k, v = args[0], args[1], args[2]
        _is_dict(m)
        m[k] = v
        return m
    h.register(HostFunction('std.map.set', _map_set, cost=1, min_args=3, max_args=3))

    def _map_keys(args):
        m=args[0]
        _is_dict(m)
        return list(m.keys())
    h.register(HostFunction('std.map.keys', _map_keys, cost=1, min_args=1, max_args=1))

    h.register(HostFunction('std.string.len', lambda a: len(str(a[0])) if a else 0, cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.string.lower', lambda a: str(a[0]).lower(), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.string.upper', lambda a: str(a[0]).upper(), cost=1, min_args=1, max_args=1))

    # --- std.string extras ---
    h.register(HostFunction('std.string.trim', lambda a: str(a[0]).strip(), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.string.replace', lambda a: str(a[0]).replace(str(a[1]), str(a[2])), cost=1, min_args=3, max_args=3))
    h.register(HostFunction('std.string.find', lambda a: str(a[0]).find(str(a[1])), cost=1, min_args=2, max_args=2))
    def _str_split(args):
        s = str(args[0])
        sep = None if len(args) < 2 else str(args[1])
        return s.split(sep) if sep is not None else s.split()
    h.register(HostFunction('std.string.split', _str_split, cost=2, min_args=1, max_args=2))
    def _str_join(args):
        arr = args[0]
        if not isinstance(arr, list):
            raise RuntimeError('std.string.join: expected list')
        sep = '' if len(args) < 2 else str(args[1])
        return sep.join(str(x) for x in arr)
    h.register(HostFunction('std.string.join', _str_join, cost=2, min_args=1, max_args=2))

    # --- std.list extras ---
    def _list_insert(args):
        lst, idx, val = args[0], int(args[1]), args[2]
        _is_list(lst)
        if idx < 0: idx = 0
        if idx > len(lst): idx = len(lst)
        lst.insert(idx, val)
        return lst
    h.register(HostFunction('std.list.insert', _list_insert, cost=1, min_args=3, max_args=3))
    def _list_remove(args):
        lst, val = args[0], args[1]
        _is_list(lst)
        try:
            lst.remove(val)
        except ValueError:
            pass
        return lst
    h.register(HostFunction('std.list.remove', _list_remove, cost=1, min_args=2, max_args=2))
    def _list_has(args):
        lst, val = args[0], args[1]
        _is_list(lst)
        return val in lst
    h.register(HostFunction('std.list.has', _list_has, cost=1, min_args=2, max_args=2))
    def _list_sort(args):
        lst = args[0]
        _is_list(lst)
        try:
            lst.sort()
        except Exception:
            # fallback: sort by string value
            lst.sort(key=lambda x: str(x))
        return lst
    h.register(HostFunction('std.list.sort', _list_sort, cost=2, min_args=1, max_args=1))

    # --- std.map extras ---
    def _map_values(args):
        m=args[0]; _is_dict(m); return list(m.values())
    h.register(HostFunction('std.map.values', _map_values, cost=1, min_args=1, max_args=1))
    def _map_has(args):
        m,k=args[0],args[1]; _is_dict(m); return k in m
    h.register(HostFunction('std.map.has', _map_has, cost=1, min_args=2, max_args=2))

    h.register(HostFunction('std.json.encode', lambda a: _json.dumps(a[0], ensure_ascii=False), cost=2, min_args=1, max_args=1))
    h.register(HostFunction('std.json.decode', lambda a: _json.loads(str(a[0])), cost=2, min_args=1, max_args=1))
    def _clamp(args):
        x, lo, hi = float(args[0]), float(args[1]), float(args[2])
        return max(lo, min(hi, x))
    h.register(HostFunction(
        name="math.clamp",
        handler=_clamp,
        cost=1,
        min_args=3,
        max_args=3
    ))

    
    # ----- std.math (advanced) -----
    import math as _math
    h.register(HostFunction('std.math.abs', lambda a: abs(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.min', lambda a: float(a[0]) if float(a[0]) < float(a[1]) else float(a[1]), cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.max', lambda a: float(a[0]) if float(a[0]) > float(a[1]) else float(a[1]), cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.floor', lambda a: _math.floor(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.ceil', lambda a: _math.ceil(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.round', lambda a: round(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.sqrt', lambda a: _math.sqrt(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.pow', lambda a: _math.pow(float(a[0]), float(a[1])), cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.sin', lambda a: _math.sin(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.cos', lambda a: _math.cos(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.tan', lambda a: _math.tan(float(a[0])), cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.atan2', lambda a: _math.atan2(float(a[0]), float(a[1])), cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.pi', lambda a: _math.pi, cost=1, min_args=0, max_args=0))
    h.register(HostFunction('std.math.clamp', _clamp, cost=1, min_args=3, max_args=3))
    def _lerp(args):
        a0, a1, t = float(args[0]), float(args[1]), float(args[2])
        return a0 + (a1 - a0) * t
    h.register(HostFunction('std.math.lerp', _lerp, cost=1, min_args=3, max_args=3))

    # ----- std.math (vectors) -----
    # Representation: vectors are plain python lists [x,y,...]
    # Design goals (MellowLang identity):
    #  - fast in VM hot loops
    #  - works for multiple domains (2D/3D/ND) without adding OOP/metatables
    #  - predictable errors
    _VEC_MIN_DIM = 2
    _VEC_MAX_DIM = 16

    def _expect_vec(v) -> int:
        if not isinstance(v, list):
            raise RuntimeError('std.math.vec: expected vector list')
        n = len(v)
        if n < _VEC_MIN_DIM or n > _VEC_MAX_DIM:
            raise RuntimeError(f'std.math.vec: dimension must be {_VEC_MIN_DIM}-{_VEC_MAX_DIM} (got {n})')
        return n

    def _vector(args):
        """Generic vector constructor.

        Supported:
          - vector(x, y, ...) / vec(x, y, ...)  (dimension inferred from arg count)
          - vector(dim, x, y, ...)             (explicit dim, must match values count)
          - vector(existing_vec)               (copy)
        """
        if len(args) == 1 and isinstance(args[0], list):
            v = args[0]
            n = _expect_vec(v)
            return [float(v[i]) for i in range(n)]

        if len(args) >= 3 and isinstance(args[0], (int, float)):
            dim = int(args[0])
            # explicit dim form only if it matches remaining values
            if dim >= _VEC_MIN_DIM and dim <= _VEC_MAX_DIM and (len(args) - 1) == dim:
                vals = args[1:]
                return [float(x) for x in vals]

        # inferred dimension
        if len(args) < _VEC_MIN_DIM:
            raise RuntimeError(f'std.math.vector: expected at least {_VEC_MIN_DIM} numbers')
        if len(args) > _VEC_MAX_DIM:
            raise RuntimeError(f'std.math.vector: too many components (max {_VEC_MAX_DIM})')
        return [float(x) for x in args]

    def _vec2(args):
        return [float(args[0]), float(args[1])]

    def _vec3(args):
        return [float(args[0]), float(args[1]), float(args[2])]

    def _vec_add(args):
        a, b = args[0], args[1]
        n = _expect_vec(a)
        if _expect_vec(b) != n:
            raise RuntimeError('std.math.vec_add: dimension mismatch')
        return [float(a[i]) + float(b[i]) for i in range(n)]

    def _vec_sub(args):
        a, b = args[0], args[1]
        n = _expect_vec(a)
        if _expect_vec(b) != n:
            raise RuntimeError('std.math.vec_sub: dimension mismatch')
        return [float(a[i]) - float(b[i]) for i in range(n)]

    def _vec_mul(args):
        a, s = args[0], float(args[1])
        n = _expect_vec(a)
        return [float(a[i]) * s for i in range(n)]

    def _vec_dot(args):
        a, b = args[0], args[1]
        n = _expect_vec(a)
        if _expect_vec(b) != n:
            raise RuntimeError('std.math.vec_dot: dimension mismatch')
        return sum(float(a[i]) * float(b[i]) for i in range(n))

    def _vec_len(args):
        a = args[0]
        n = _expect_vec(a)
        return _math.sqrt(sum(float(a[i]) * float(a[i]) for i in range(n)))

    def _vec_norm(args):
        a = args[0]
        n = _expect_vec(a)
        l = _math.sqrt(sum(float(a[i]) * float(a[i]) for i in range(n)))
        if l == 0:
            return [0.0 for _ in range(n)]
        return [float(a[i]) / l for i in range(n)]

    def _vec_dist(args):
        a, b = args[0], args[1]
        n = _expect_vec(a)
        if _expect_vec(b) != n:
            raise RuntimeError('std.math.vec_dist: dimension mismatch')
        return _math.sqrt(sum((float(a[i]) - float(b[i]))**2 for i in range(n)))

    def _vec_dim(args):
        return _expect_vec(args[0])

    def _vec_axis(args):
        v, idx = args[0], args[1]
        n = _expect_vec(v)
        try:
            i = int(idx)
        except Exception:
            raise RuntimeError('std.math.vec_axis: index must be int')
        if i < 0 or i >= n:
            raise RuntimeError(f'std.math.vec_axis: index out of range (0..{n-1}, got {i})')
        return float(v[i])

    def _vec_lerp(args):
        a, b, t = args[0], args[1], float(args[2])
        n = _expect_vec(a)
        if _expect_vec(b) != n:
            raise RuntimeError('std.math.vec_lerp: dimension mismatch')
        return [float(a[i]) + (float(b[i]) - float(a[i])) * t for i in range(n)]

    def _vec_limit(args):
        v, max_len = args[0], float(args[1])
        n = _expect_vec(v)
        if max_len < 0:
            max_len = 0.0
        l = _math.sqrt(sum(float(v[i]) * float(v[i]) for i in range(n)))
        if l == 0 or l <= max_len:
            return [float(v[i]) for i in range(n)]
        s = max_len / l
        return [float(v[i]) * s for i in range(n)]

    # register
    h.register(HostFunction('std.math.vector', _vector, cost=1, min_args=1, max_args=_VEC_MAX_DIM+1))
    h.register(HostFunction('std.math.vec2', _vec2, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec3', _vec3, cost=1, min_args=3, max_args=3))
    h.register(HostFunction('std.math.vec_add', _vec_add, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec_sub', _vec_sub, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec_mul', _vec_mul, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec_dot', _vec_dot, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec_len', _vec_len, cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.vec_norm', _vec_norm, cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.vec_dist', _vec_dist, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec_dim', _vec_dim, cost=1, min_args=1, max_args=1))
    h.register(HostFunction('std.math.vec_axis', _vec_axis, cost=1, min_args=2, max_args=2))
    h.register(HostFunction('std.math.vec_lerp', _vec_lerp, cost=1, min_args=3, max_args=3))
    h.register(HostFunction('std.math.vec_limit', _vec_limit, cost=1, min_args=2, max_args=2))

    # ----- std.time (advanced) -----
    import time as _time
    h.register(HostFunction('std.time.unix', lambda a: _time.time(), cost=1, min_args=0, max_args=0))
    h.register(HostFunction('std.time.ms', lambda a: int(_time.time() * 1000), cost=1, min_args=0, max_args=0))
    # Note: std.time.now is monotonic since host start; not guaranteed deterministic unless replayed
    start = _time.perf_counter()
    h.register(HostFunction('std.time.now', lambda a: _time.perf_counter() - start, cost=1, min_args=0, max_args=0))

# range (Python-like): std.range(end) or std.range(start, end, step)
    def _std_range(args):
        # returns an iterator-like view (no list allocation)
        if len(args) == 1:
            start, end, step = 0, int(args[0]), 1
        elif len(args) == 2:
            start, end, step = int(args[0]), int(args[1]), 1
        elif len(args) == 3:
            start, end, step = int(args[0]), int(args[1]), int(args[2])
        else:
            raise RuntimeError('std.range: expected 1-3 args')
        if step == 0:
            raise RuntimeError('std.range: step cannot be 0')
        return MellowLangRange(start, end, step)

    h.register(HostFunction(
        name='std.range',
        handler=_std_range,
        cost=1,
        min_args=1,
        max_args=3
    ))

    return h
