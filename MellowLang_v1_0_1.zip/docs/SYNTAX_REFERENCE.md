# MellowLang Syntax Reference (v1.0.1)

ดูไฟล์ `MELLOWLANG_User_Manual.md` สำหรับคู่มือเต็ม
