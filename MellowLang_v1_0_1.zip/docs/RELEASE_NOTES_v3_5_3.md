# MellowLang v3.5.3 Release Notes

## Fixes
- Fixed PyInstaller build so the generated `mellowlang.exe` reliably includes the `mellow` Python package
  (prevents `ModuleNotFoundError: No module named 'mellowlang.cli'` on startup).
- Improved build script to use a stable launcher (`run_mellowlang.py`) and collect all submodules.

## Packaging
- Installer continues to bundle: docs/, examples/, project_template/, README, LICENSE, SIGNATURE.
- VS Code extension auto-install step kept (via `code.cmd --install-extension ...`) when VS Code is detected.

## Notes
- If you have a pip-installed `mellowlang.exe` under Python Scripts, ensure the installer PATH prepends
  `{app}` so `mellow` resolves to the installed MellowLang binary first.
