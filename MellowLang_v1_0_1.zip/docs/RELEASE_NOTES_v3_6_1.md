# MellowLang v3.6.1

## Fixes
- **No implicit disk writes on script run**: VM no longer auto-creates `frinds_saves/` or writes `__keep__*.json` snapshots unless you explicitly call save commands.
- `load_data` no longer creates `frinds_saves/` when the requested file does not exist.
- Global seed is kept in-memory; it is not persisted to disk implicitly.

## Notes
- Explicit storage APIs (`save_data` / `load_data`, VM `save` opcode) still work. The sandbox default remains safe and deterministic.
