from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any

from mellowlang import __version__
from mellowlang.compiler import Compiler
from mellowlang.host import MODULE_ALLOWLIST, default_host
from mellowlang.lint import format_source, lint_source
from mellowlang.replay import ReplayConfig
from mellowlang.vm import MellowLangVM


# ----------------------------
# Console helpers
# ----------------------------

def _supports_ansi() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.name != "nt":
        return True
    env = os.environ
    return any(k in env for k in ("WT_SESSION", "TERM", "ANSICON", "ConEmuANSI")) or (
        "vscode" in env.get("TERM_PROGRAM", "").lower()
    )


def _print_pretty_error(
    err: Exception,
    filename: str | None = None,
    source_lines: list[str] | None = None,
    *,
    use_color: bool | None = None,
) -> None:
    msg = str(err)
    if use_color is None:
        use_color = _supports_ansi()

    if use_color:
        RED = "\033[31m"
        YELLOW = "\033[33m"
        BLUE = "\033[34m"
        DIM = "\033[2m"
        BOLD = "\033[1m"
        RESET = "\033[0m"
    else:
        RED = YELLOW = BLUE = DIM = BOLD = RESET = ""

    print(f"{RED}error:{RESET} {msg}")

    trace = getattr(err, "trace", None)
    if trace:
        print(f"{BOLD}call stack:{RESET}")
        for fr in reversed(trace):
            nm = fr.get("name", "<frame>")
            fn = fr.get("filename", filename) or "<script>"
            ln = fr.get("line")
            col = fr.get("col")
            loc = fn if ln is None else f"{fn}:{ln}" + (f":{col}" if col else "")
            print(f"  {BLUE}at{RESET} {nm} ({loc})")

    if not filename or not source_lines:
        return

    line_no = getattr(err, "line", None)
    col = getattr(err, "col", None)
    if not line_no:
        return

    line_no = int(line_no)
    col = int(col or 1)

    print(f"{DIM}--> {filename}:{line_no}:{col}{RESET}")
    lo = max(1, line_no - 1)
    hi = min(len(source_lines), line_no + 1)
    for ln in range(lo, hi + 1):
        src = source_lines[ln - 1].rstrip("\n")
        prefix = ">" if ln == line_no else " "
        pfx = f"{YELLOW}{prefix}{RESET}" if ln == line_no else prefix
        print(f"{pfx} {ln:4d} | {src}")
        if ln == line_no:
            caret_col = max(1, min(col, len(src) + 1))
            print("  " + " " * 4 + " | " + " " * (caret_col - 1) + f"{YELLOW}^{RESET}")


def _prog_name() -> str:
    base = os.path.basename(sys.argv[0]) or "mellow"
    return os.path.splitext(base)[0]


def _parse_json_args(raw: str | None) -> list[Any]:
    if not raw:
        return []
    try:
        data = json.loads(raw)
        return data if isinstance(data, list) else [data]
    except Exception:
        return []


DEFAULT_EXTS = (".mellow", ".fds", ".frinds")


# ----------------------------
# Commands
# ----------------------------

def cmd_run(args: argparse.Namespace) -> int:
    path = Path(args.script)
    if not path.exists():
        print(f"error: file not found: {path}")
        return 2

    src = path.read_text(encoding="utf-8", errors="replace")
    lines = src.splitlines(True)

    host = default_host()
    compiler = Compiler(host=host)
    vm = MellowLangVM(host=host)

    use_color = True if args.color else (False if args.no_color else None)

    try:
        if args.global_seed is not None:
            vm.set_global_seed(int(args.global_seed))
        if args.seed is not None:
            vm.set_seed(int(args.seed))

        if args.replay_path:
            cfg = ReplayConfig(replay_path=str(args.replay_path))
            vm.enable_replay(cfg)
        elif args.record_path:
            cfg = ReplayConfig(record_path=str(args.record_path))
            vm.enable_replay(cfg)

        program = compiler.compile_source(src, filename=str(path))
        result = vm.run_program(program, filename=str(path))

        # optional emit
        if args.emit_name:
            ev_args = _parse_json_args(args.emit_args_raw)
            vm.emit(args.emit_name, ev_args)

        if args.json:
            print(json.dumps({"ok": True, "result": result}, ensure_ascii=False))
        return 0
    except Exception as e:
        _print_pretty_error(e, str(path), [ln.rstrip("\n") for ln in lines], use_color=use_color)
        if args.json:
            print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
        return 1


def cmd_check(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.exists():
        print(f"error: file not found: {path}")
        return 2
    src = path.read_text(encoding="utf-8", errors="replace")
    issues = lint_source(src)

    if args.json:
        data = [
            {"kind": it.kind, "message": it.message, "line": it.line}
            for it in issues
        ]
        print(json.dumps({"file": str(path), "issues": data}, ensure_ascii=False, indent=2))
    else:
        if not issues:
            print("✓ ok")
        else:
            for it in issues:
                loc = f":{it.line}" if it.line else ""
                print(f"{it.kind}{loc}: {it.message}")

    return 0 if not issues else 1


def cmd_fmt(args: argparse.Namespace) -> int:
    files = [Path(f) for f in args.files]
    if not files:
        print("error: no files provided")
        return 2

    changed = 0
    for p in files:
        if not p.exists():
            print(f"skip: not found: {p}")
            continue
        src = p.read_text(encoding="utf-8", errors="replace")
        out = format_source(src)
        if args.check:
            if out != src:
                print(f"would format: {p}")
                changed += 1
            continue
        if args.in_place:
            if out != src:
                p.write_text(out, encoding="utf-8")
                print(f"formatted: {p}")
                changed += 1
        else:
            # print to stdout (single file recommended)
            sys.stdout.write(out)
    return 0 if (not args.check or changed == 0) else 1


def cmd_init(args: argparse.Namespace) -> int:
    dest = Path(args.dir).resolve()
    template = Path(__file__).resolve().parents[2] / "project_template"

    if not template.exists():
        print("error: project_template not found (packaging issue).")
        return 2

    if dest.exists() and any(dest.iterdir()) and not args.force:
        print("error: destination is not empty. Use --force to overwrite.")
        return 2

    if dest.exists() and args.force:
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    shutil.copytree(template, dest, dirs_exist_ok=True)
    print(f"✓ created project: {dest}")
    return 0


def cmd_modules(args: argparse.Namespace) -> int:
    if args.json:
        print(json.dumps(MODULE_ALLOWLIST, ensure_ascii=False, indent=2))
        return 0

    print("Allowed modules (get/import):")
    for name in sorted(MODULE_ALLOWLIST.keys()):
        funcs = MODULE_ALLOWLIST[name]
        print(f"- {name} ({len(funcs)} symbols)")
    print("\nTip: import \"math\" as m  ->  m[\"sqrt\"]")
    return 0


def cmd_lsp(_: argparse.Namespace) -> int:
    from mellowlang.lsp_server import start_lsp
    return int(start_lsp() or 0)


# ----------------------------
# Parser / help
# ----------------------------

def build_modern_parser() -> argparse.ArgumentParser:
    """
    Modern (subcommand) CLI.
    """
    prog = _prog_name()
    desc = f"MellowLang {__version__} — sandbox scripting language (game/AI focused)"
    p = argparse.ArgumentParser(
        prog=prog,
        description=desc,
        formatter_class=argparse.RawTextHelpFormatter,
    )

    p.add_argument("--version", action="version", version=f"{prog} {__version__}")

    sub = p.add_subparsers(dest="cmd")

    # run
    pr = sub.add_parser("run", help="Run a script file (.mellow/.fds/.frinds).")
    pr.add_argument("script", help="Script path.")
    pr.add_argument("--emit", dest="emit_name", help="Emit an event after script run (for .fds workflows).")
    pr.add_argument("--emit-args", dest="emit_args_raw", help="JSON array for event args, e.g. [0.16].")
    mx = pr.add_mutually_exclusive_group()
    mx.add_argument("--record", dest="record_path", help="Record deterministic replay log to a .jsonl file.")
    mx.add_argument("--replay", dest="replay_path", help="Replay from deterministic log (.jsonl).")
    pr.add_argument("--seed", type=int, help="Per-script seed for deterministic random.")
    pr.add_argument("--global-seed", type=int, help="Global base seed for deterministic runs across scripts.")
    pr.add_argument("--color", action="store_true", help="Force colored error output (ANSI).")
    pr.add_argument("--no-color", action="store_true", help="Disable colored error output.")
    pr.add_argument("--json", action="store_true", help="Print machine-readable JSON result/error.")
    pr.set_defaults(_handler=cmd_run)

    # check
    pc = sub.add_parser("check", help="Syntax/style check a file.")
    pc.add_argument("file", help="Script path.")
    pc.add_argument("--json", action="store_true", help="Output issues as JSON.")
    pc.set_defaults(_handler=cmd_check)

    # fmt
    pf = sub.add_parser("fmt", help="Format file(s).")
    pf.add_argument("files", nargs="+", help="Files to format.")
    pf.add_argument("--check", action="store_true", help="Exit non-zero if files would change.")
    pf.add_argument("-w", "--in-place", action="store_true", help="Rewrite files in-place.")
    pf.set_defaults(_handler=cmd_fmt)

    # init
    pi = sub.add_parser("init", help="Create a new MellowLang project from template.")
    pi.add_argument("dir", help="Destination folder.")
    pi.add_argument("--force", action="store_true", help="Overwrite if destination exists.")
    pi.set_defaults(_handler=cmd_init)

    # modules
    pm = sub.add_parser("modules", help="List allowed host modules.")
    pm.add_argument("--json", action="store_true", help="Output as JSON.")
    pm.set_defaults(_handler=cmd_modules)

    # lsp
    pl = sub.add_parser("lsp", help="Start MellowLang Language Server (LSP) for VS Code.")
    pl.set_defaults(_handler=cmd_lsp)

    return p


def build_legacy_parser() -> argparse.ArgumentParser:
    """
    Legacy-compatible CLI (Frinds-style), kept for familiarity and backwards-compat.
    """
    prog = _prog_name()
    p = argparse.ArgumentParser(
        prog=prog,
        formatter_class=argparse.RawTextHelpFormatter,
        description=f"MellowLang {__version__} (legacy-compatible CLI)
"
                    f"Tip: You can also use modern subcommands: {prog} run/check/fmt/init/modules/lsp",
    )

    # positional
    p.add_argument("script", nargs="?", help="Path to script file (.mellow / .fds / .frinds).")

    # options (match legacy UX)
    p.add_argument("--lsp", action="store_true", help="Start MellowLang Language Server (LSP) for VS Code.")
    p.add_argument("--engine", action="store_true",
                   help="(Deprecated) Legacy mode flag. For parity, it runs VM by default.")
    p.add_argument("--legacy", action="store_true",
                   help="Force legacy interpreter mode (compat). If unavailable, falls back to VM.")
    p.add_argument("--emit", dest="emit_name", help="Emit an event after script run.")
    p.add_argument("--emit-args", dest="emit_args_raw",
                   help='JSON array for event args, e.g. [0.16] or ["p1", 10].')

    mx = p.add_mutually_exclusive_group()
    mx.add_argument("--record", dest="record_path", help="Record deterministic replay log to a .jsonl file.")
    mx.add_argument("--replay", dest="replay_path", help="Replay from deterministic log (.jsonl).")

    p.add_argument("--seed", type=int, help="Per-script seed for deterministic random.")
    p.add_argument("--global-seed", type=int,
                   help="Global base seed for deterministic runs across scripts (global_seed).")

    p.add_argument("--color", action="store_true", help="Force colored error output (ANSI).")
    p.add_argument("--no-color", action="store_true", help="Disable colored error output.")
    p.add_argument("--json", action="store_true", help="Print machine-readable JSON result/error.")

    # new convenience flags (v1.0.2)
    p.add_argument("--check", dest="check_only", action="store_true",
                   help="(New) Only check syntax/style; do not run.")
    p.add_argument("--modules", dest="list_modules", action="store_true",
                   help="(New) List allowed host modules (same as: modules).")

    p.add_argument("--version", action="version", version=f"{prog} {__version__}")
    return p


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    modern_cmds = {"run", "check", "fmt", "init", "modules", "lsp"}

    # Decide mode:
    # - If first token is a modern subcommand -> modern parser
    # - Otherwise -> legacy parser (Frinds-style flags + positional script)
    if argv and argv[0] in modern_cmds:
        p = build_modern_parser()
        args = p.parse_args(argv)
        handler = getattr(args, "_handler", None)
        if not handler:
            p.print_help()
            return 2
        return int(handler(args) or 0)

    # Legacy mode
    p = build_legacy_parser()
    args = p.parse_args(argv)

    # Legacy helpers
    if getattr(args, "list_modules", False):
        return int(cmd_modules(argparse.Namespace(json=False)) or 0)

    if getattr(args, "lsp", False):
        return int(cmd_lsp(argparse.Namespace()) or 0)

    if not getattr(args, "script", None):
        # No script provided: show legacy help + hint about modern commands
        p.print_help()
        sys.stderr.write("\nModern commands:\n  mellow run <file>\n  mellow check <file>\n  mellow fmt <files...>\n  mellow init <dir>\n  mellow modules\n  mellow lsp\n\n")
        return 2

    # Engine flags are kept for compatibility; MellowLang currently runs on VM.
    if getattr(args, "engine", False) or getattr(args, "legacy", False):
        _warn("Note: --engine/--legacy are compatibility flags; MellowLang uses VM by default.")

    if getattr(args, "check_only", False):
        # Map to modern check handler
        return int(cmd_check(argparse.Namespace(file=args.script, json=getattr(args, "json", False))) or 0)

    return int(cmd_run(args) or 0)
