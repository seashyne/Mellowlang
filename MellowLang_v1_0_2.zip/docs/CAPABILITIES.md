# MellowLang Capabilities (v1.0.2)

เอกสารนี้สรุป “ความสามารถปัจจุบัน” ของ **MellowLang** ณ เวอร์ชัน **1.0.2** เพื่อใช้เป็นไฟล์อ้างอิงในโปรเจกต์/ทีม

## 1) Core
- รันสคริปต์แบบ sandbox ผ่าน VM (MellowLangVM)
- รองรับไฟล์: `.mellow` (แนะนำ), `.fds`, และ legacy `.frinds`
- ระบบ error ที่อ่านง่าย + รองรับสี (ANSI) ผ่าน `--color/--no-color`
- โหมดผลลัพธ์ JSON สำหรับ tooling ผ่าน `--json`

## 2) Deterministic / Replay
- `--seed` : seed เฉพาะสคริปต์
- `--global-seed` : seed ฐานร่วม (เหมาะกับ run หลายไฟล์/หลายครั้ง)
- `--record <path.jsonl>` : บันทึก log deterministic
- `--replay <path.jsonl>` : replay จาก log เดิม

## 3) Events (สำหรับ workflow แบบ .fds)
- `--emit <name>` : emit event หลังรันจบ
- `--emit-args <json-array>` : ส่ง args ให้ event (เช่น `[0.16]` หรือ `["p1",10]`)

## 4) Tooling
- Language Server (LSP): `mellow --lsp` หรือ `mellow lsp`
- Syntax/Lint: `mellow --check <file>` หรือ `mellow check <file>`
- Formatter: `mellow fmt ...` (โหมดใหม่)

## 5) Host Modules
- มี allowlist ของโมดูลที่อนุญาตให้สคริปต์เรียกใช้ (เพื่อความปลอดภัย)
- ดูรายการได้ด้วย `mellow --modules` หรือ `mellow modules`

> หมายเหตุ: `--engine` และ `--legacy` เป็น “compat flags” (คงไว้เพื่อความคุ้นเคย) แต่ MellowLang ใช้ VM เป็นค่าเริ่มต้น
