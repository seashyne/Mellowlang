# MellowLang v3.5.1 (Installer-ready)

## เปลี่ยนแปลงหลัก
- ปรับโครงสร้างโปรเจกต์เป็น `src/` layout เพื่อแพ็ก EXE/Installer และทำ VS Code extension ได้ง่ายขึ้น
- ย้าย CLI ไปที่ `src/frinds/cli.py` และเพิ่ม `python -m frinds`
- ย้ายสคริปต์ทดสอบไปที่ `examples/`
- เพิ่มไฟล์ packaging (PyInstaller build + Inno Setup .iss)
- เพิ่ม skeleton VS Code extension (syntax highlight)

## วิธีรัน
- `python -m mellow examples/v3_5_0_test_vector.frinds`
