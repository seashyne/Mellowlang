# MellowLang v3.6.0

## เปลี่ยนแปลงสำคัญ
- ปรับ Installer ให้แก้ไข PATH พร้อม `ChangesEnvironment=yes` (โปรแกรมใหม่จะเห็น PATH ทันที; VS Code ที่เปิดค้างต้องปิด/เปิดใหม่)
- VS Code Extension เพิ่มการค้นหา `mellowlang.exe` อัตโนมัติ (Program Files / LocalAppData) และเพิ่ม setting `mellowlang.executablePath`
- แก้ปัญหา MellowLang สร้างโฟลเดอร์ `frinds_saves/` เองโดยไม่ถูกสั่ง (จะสร้างเมื่อใช้คำสั่ง save/load เท่านั้น)
- ปรับ `--engine` ให้เป็นโหมด Deprecated และรัน VM เพื่อให้ผลลัพธ์สอดคล้องกัน (ใช้ `--legacy` หากต้องการบังคับใช้ MellowLangEngine เดิม)

## หมายเหตุ
- ถ้าติดตั้ง MellowLang แล้ว VS Code ยังรัน LSP ไม่ได้ ให้:
  1) ปิด VS Code ทุกหน้าต่างแล้วเปิดใหม่
  2) หรือกำหนด `mellowlang.executablePath` ไปที่ `C:\Program Files\MellowLang\mellowlang.exe`
