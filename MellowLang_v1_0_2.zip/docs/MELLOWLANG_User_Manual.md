# MellowLang v1.0.2 — คู่มือการใช้งาน (User Manual)

> ภาษา scripting แบบ sandbox สำหรับงานเกม/AI: อ่านง่าย, รันได้เร็ว, ทำซ้ำผลได้ (deterministic / replay)

---

## 1) เริ่มต้นใช้งาน

### ติดตั้งและเช็คเวอร์ชัน
```bash
mellow --version
```

### รันสคริปต์
```bash
mellow run examples/hello.mellow
# หรือ (โหมด compatibility)
mellow examples/hello.mellow
```

### เช็ค syntax / style
```bash
mellow check examples/loops.mellow
```

### จัดรูปแบบไฟล์ (format)
```bash
mellow fmt -w examples/hello.mellow
```

### สร้างโปรเจกต์ใหม่จาก template
```bash
mellow init MyProject
```

---

## 2) ไฟล์ที่รองรับ

- **`.mellow`**: สคริปต์ทั่วไป (แนะนำ)
- **`.fds`**: สคริปต์แนว event-driven (ใช้ `on("event", ...):`)
- **`.frinds`**: legacy compatibility (ยังอ่านได้ แต่ไม่แนะนำกับงานใหม่)

---

## 3) คอมเมนต์และการจัดบล็อก (Block)

### คอมเมนต์
- คอมเมนต์ทั้งบรรทัด/ท้ายบรรทัดใช้ `//`
```mellow
// comment
show("hi") // comment
```

### บล็อกด้วย `:` + indent (Python style) และปิดด้วย `end` (Lua style ได้)
```mellow
check (x > 0):
    show("positive")
end
```

> ภายในบล็อกใช้ indent **4 spaces** เป็นมาตรฐาน (อย่าใช้ tab)

---

## 4) ชนิดข้อมูล (Literals)

- Number: `1`, `3.14`
- String: `"hello"` (รองรับ escape `\"` และ `\\`)
- Boolean: `true`, `false`
- None: `none` หรือ `null`
- List: `[1, 2, 3]`
- Map: `{"a": 1, "b": 2}`

ตัวอย่าง map/list แบบหลายบรรทัด (parser รองรับ)
```mellow
keep data = {
    "name": "mellow",
    "score": 42
}
```

---

## 5) ตัวแปรและการกำหนดค่า

### `keep` (แนะนำสำหรับ state ในเกม/AI)
```mellow
keep score = 0
score = score + 1
```

### Multi-assign
```mellow
keep a, b = 1, 2
a, b = b, a
```

> หมายเหตุ: target ฝั่งซ้ายต้องเป็นชื่อ identifier (ยังไม่รองรับ assign เข้า index เช่น `xs[0] = ...` ในเวอร์ชันนี้)

---

## 6) นิพจน์ (Expressions)

### ตัวดำเนินการที่รองรับ
- คณิตศาสตร์: `+ - * /`
- เปรียบเทียบ: `== != > < >= <=`
- ตรรกะ: `and or not`
- วงเล็บ: `( ... )`
- index: `xs[0]`, `m["key"]`
- เรียกฟังก์ชัน: `name(arg1, arg2)`

---

## 7) เงื่อนไข (If)

### รูปแบบหลัก: `check / also / else`
```mellow
check (hp <= 0):
    show("dead")
also (hp < 20):
    show("low hp")
else:
    show("ok")
end
```

### alias แบบ Python: `if / elif / else`
```mellow
if (x > 0):
    show("pos")
elif (x < 0):
    show("neg")
else:
    show("zero")
end
```

---

## 8) Loop ทั้งหมด

### 8.1 loop while (หลัก)
```mellow
keep i = 0
loop (i < 5):
    show(i)
    i = i + 1
end
```

### 8.2 loop count < N (นับรอบแบบ sandbox-friendly)
```mellow
loop count < 10:
    show("tick")
end
```

### 8.3 foreach list
```mellow
keep xs = [10, 20, 30]
loop x in xs:
    show(x)
end
```

### 8.4 foreach map (key, value)
```mellow
keep m = {"a": 1, "b": 2}
loop k, v in m:
    show(k)
end
```

### 8.5 for-range (Lua-like)
รองรับ 3 แบบ:
- `for i = end do` (start=1)
- `for i = start, end do`
- `for i = start, end, step do`

```mellow
for i = 1, 10, 2 do
    show(i)
end
```

### 8.6 repeat-until (Lua-like)
```mellow
keep x = 0
repeat:
    x = x + 1
until (x >= 3)
```

### 8.7 คำสั่งควบคุม loop
- `break`
- `continue`

---

## 9) ฟังก์ชัน (skill) และ return

### สร้างฟังก์ชัน
```mellow
skill add(a, b):
    return a + b
end

show(add(2, 3))
```

### return เปล่า
```mellow
skill ping():
    return
end
```

---

## 10) Event handler (on) สำหรับ .fds

```mellow
on("tick", dt):
    show("dt=" + dt)
end
```

เรียก emit จาก CLI:
```bash
mellow run examples/events.fds --emit tick --emit-args [0.016]
```

---

## 11) try/catch/finally

```mellow
try:
    show("work")
catch err:
    show("caught: " + err)
finally:
    show("cleanup")
end
```

---

## 12) Builtins สำคัญ

### 12.1 show
พิมพ์ข้อความ/ค่า (debug)
```mellow
show("hi")
```

### 12.2 precision
ตั้งการปัดเศษตอนแสดงผล (ขึ้นกับ VM/host)
```mellow
precision(3)
```

### 12.3 wait / stop
- `wait(x)` จะถูกอนุญาตหรือไม่ขึ้นกับ sandbox config
- `stop` หยุดรันทันที

### 12.4 save/load
```mellow
save {"score": 1} into "save.json"
load "save.json" into data
```

### 12.5 put (ใส่ค่าเข้า list)
```mellow
keep xs = []
put 10 into xs
```

---

## 13) โมดูลมาตรฐาน (allowlist) — get/import + call

MellowLang ไม่อนุญาต import อิสระแบบ Python แต่ให้ใช้ allowlist ผ่าน `get()/import` และเรียกด้วย `call()` เพื่อคุม sandbox

### โหลดโมดูล
```mellow
import "math" as m
```

### เรียกฟังก์ชันในโมดูลด้วย call()
ค่าที่อยู่ใน `m["sqrt"]` เป็น “ชื่อ syscall” (เช่น `std.math.sqrt`)
```mellow
import "math" as m
keep r = call(m["sqrt"], 9)
show(r)
```

ดูรายการโมดูลที่อนุญาต:
```bash
mellow modules
mellow modules --json
```

โมดูลหลัก:
- `math`, `time`, `list`, `map`, `string`, `json`

---

## 14) CLI (สรุปคำสั่ง)

```text
mellow run <file> [--record <log.jsonl> | --replay <log.jsonl>] [--seed N] [--global-seed N]
mellow check <file>
mellow fmt [-w] [--check] <files...>
mellow init <dir> [--force]
mellow modules [--json]
mellow lsp
```

---

## 15) ตัวอย่างที่แนะนำ

- `examples/hello.mellow`
- `examples/loops.mellow`
- `examples/skills.mellow`
- `examples/try_catch.mellow`
- `examples/vectors.mellow`
- `examples/events.fds`
- `examples/storage.mellow`

