const vscode = require('vscode');
const path = require('path');
const fs = require('fs');

const lc = require('vscode-languageclient/node');
let client;

function resolveMellowLangCommand(output) {
  const cfg = vscode.workspace.getConfiguration('mellowlang');
  const userPath = String(cfg.get('executablePath') || '').trim();
  if (userPath) {
    return userPath;
  }

  // Auto-detect common Windows install locations
  if (process.platform === 'win32') {
    const candidates = [];
    if (process.env.ProgramFiles) {
      candidates.push(path.join(process.env.ProgramFiles, 'MellowLang', 'mellow.exe'));
    }
    if (process.env.LOCALAPPDATA) {
      candidates.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'MellowLang', 'mellow.exe'));
    }
    // VS Code portable / custom installs: fallback to PATH below
    for (const p of candidates) {
      try {
        if (fs.existsSync(p)) return p;
      } catch {}
    }
    if (output) {
      output.appendLine('[MellowLang] mellow.executablePath not set and mellow.exe not found in Program Files. Falling back to PATH.');
    }
  }

  // Default: rely on PATH
  return 'mellow';
}

/**
 * @param {vscode.ExtensionContext} context
 */
function activate(context) {
  const output = vscode.window.createOutputChannel('MellowLang');
  output.appendLine('MellowLang extension activated');

  function startClient() {
    const cmd = resolveMellowLangCommand(output);

    const serverOptions = {
      command: cmd,
      args: ['--lsp'],
      options: {}
    };

    const clientOptions = {
      documentSelector: [{ scheme: 'file', language: 'mellow' }],
      outputChannel: output
    };

    try {
      client = new lc.LanguageClient('mellowlang', 'MellowLang Language Server', serverOptions, clientOptions);
      client.start();
      output.appendLine('MellowLang LSP started (' + cmd + ' --lsp)');
    } catch (e) {
      output.appendLine('Failed to start MellowLang LSP: ' + String(e));
    }
  }

  startClient();

  context.subscriptions.push(vscode.commands.registerCommand('mellowlang.restartLanguageServer', async () => {
    if (client) {
      try { await client.stop(); } catch {}
      client = undefined;
    }
    startClient();
  }));

  context.subscriptions.push(output);
}

function deactivate() {
  if (client) {
    return client.stop();
  }
  return undefined;
}

module.exports = {
  activate,
  deactivate
};
