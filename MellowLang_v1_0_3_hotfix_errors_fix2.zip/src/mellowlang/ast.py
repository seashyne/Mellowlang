# frinds/ast.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional, Tuple

# --------- Program / Statements ---------

@dataclass
class Program:
    body: List["Stmt"]


class Stmt: ...


# ----- Simple statements -----

@dataclass
class KeepStmt(Stmt):
    name: str
    expr: "Expr"


@dataclass
class KeepMultiStmt(Stmt):
    """Multi-assign keep: keep a, b = expr1, expr2"""
    names: List[str]
    exprs: List["Expr"]


@dataclass
class AssignStmt(Stmt):
    """General assignment: a = expr or a,b = expr1,expr2 (parallel)."""
    names: List[str]
    exprs: List["Expr"]


@dataclass
class ExprStmt(Stmt):
    """Standalone expression statement (e.g. list_push(items, x))."""
    expr: "Expr"


@dataclass
class ShowStmt(Stmt):
    expr: "Expr"


@dataclass
class PrecisionStmt(Stmt):
    expr: "Expr"


@dataclass
class StopStmt(Stmt):
    pass


@dataclass
class WaitStmt(Stmt):
    expr: "Expr"


@dataclass
class SaveStmt(Stmt):
    value_expr: "Expr"
    filename_expr: "Expr"


@dataclass
class LoadStmt(Stmt):
    filename_expr: "Expr"
    var_name: str


@dataclass
class PutStmt(Stmt):
    item_expr: "Expr"
    list_name: str


@dataclass
class ReturnStmt(Stmt):
    expr: Optional["Expr"]


@dataclass
class BreakStmt(Stmt):
    pass


@dataclass
class ContinueStmt(Stmt):
    pass


@dataclass
class TryStmt(Stmt):
    try_body: List["Stmt"]
    catch_name: Optional[str]
    catch_body: Optional[List["Stmt"]]
    finally_body: Optional[List["Stmt"]]


# ----- Definitions -----

@dataclass
class SkillDef(Stmt):
    name: str
    params: List[str]
    body: List["Stmt"]


@dataclass
class IfGroup(Stmt):
    branches: List[Tuple["Expr", List["Stmt"]]]
    else_block: Optional[List["Stmt"]]


@dataclass
class LoopWhile(Stmt):
    cond: "Expr"
    body: List["Stmt"]


@dataclass
class LoopForEach(Stmt):
    var_name: str
    iterable: "Expr"
    body: List["Stmt"]


@dataclass
class LoopForMap(Stmt):
    key_name: str
    value_name: str
    iterable: "Expr"   # must be map/dict at runtime
    body: List["Stmt"]


@dataclass
class DoBlock(Stmt):
    """Lua-style do ... end scope (syntax sugar for an explicit block)."""
    body: List["Stmt"]


@dataclass
class LoopForRange(Stmt):
    var_name: str
    start: "Expr"
    end: "Expr"
    step: Optional["Expr"]  # None => friendly default step
    body: List["Stmt"]


@dataclass
class RepeatUntil(Stmt):
    body: List["Stmt"]
    cond: "Expr"


@dataclass
class LoopCount(Stmt):
    limit: "Expr"   # loop count < limit
    body: List["Stmt"]


@dataclass
class OnDef(Stmt):
    event: str
    params: List[str]
    body: List["Stmt"]


# --------- Expressions ---------

class Expr: ...


@dataclass
class Literal(Expr):
    value: Any


@dataclass
class Var(Expr):
    name: str


@dataclass
class UnaryOp(Expr):
    op: str
    expr: Expr


@dataclass
class BinaryOp(Expr):
    op: str
    left: Expr
    right: Expr


@dataclass
class Call(Expr):
    name: str
    args: List[Expr]


@dataclass
class Index(Expr):
    target: Expr
    index: Expr


@dataclass
class ListLiteral(Expr):
    items: List[Expr]


@dataclass
class MapLiteral(Expr):
    pairs: List[Tuple[Expr, Expr]]
