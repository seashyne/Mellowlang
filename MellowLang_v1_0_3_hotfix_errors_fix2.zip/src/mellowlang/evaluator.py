# frinds/evaluator.py
import re

class Evaluator:
    def __init__(self, engine):
        self.engine = engine

    def evaluate(self, expr):
        expr = (expr or "").strip()
        if not expr:
            return None

        # Boolean literals
        if expr.lower() == "true": return True
        if expr.lower() == "false": return False
        if expr.lower() == "none" or expr.lower() == "null": return None

        # --- List Index Access (player_stats[1]) must come BEFORE variable-not-found error ---
        if "[" in expr and expr.endswith("]") and expr.count("[") == 1:
            var_name = expr[:expr.find("[")].strip()
            index_expr = expr[expr.find("[")+1 : -1].strip()
            if var_name in self.engine.variables:
                target = self.engine.variables[var_name]
                try:
                    idx = int(self.evaluate(index_expr))
                except:
                    idx = 0
                if isinstance(target, list) and 0 <= idx < len(target):
                    return target[idx]

        # String literal
        if expr.startswith('"') and expr.endswith('"') and expr.count('"') == 2:
            return expr[1:-1]

        # Number literal (int/float)
        is_num = expr.replace('.', '', 1).replace('-', '', 1).isdigit()
        if is_num and not any(op in expr for op in "+-*/"):
            return float(expr) if '.' in expr else int(expr)

        # Function call / skill call: name(...)
        if "(" in expr and expr.endswith(")"):
            name = expr[:expr.find("(")].strip()
            content = expr[expr.find("(")+1 : expr.rfind(")")].strip()

            args_raw = re.split(r',(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', content) if content else []
            args = [self.evaluate(a.strip()) for a in args_raw if a.strip()]

            # Math core
            if hasattr(self.engine, 'math_core') and name in getattr(self.engine.math_core, 'commands', []):
                return self.engine.math_core.execute(name, args)

            # Storage core
            if hasattr(self.engine, 'storage_core') and name in getattr(self.engine.storage_core, 'commands', []):
                return self.engine.storage_core.execute(name, args)

            # Built-ins (sandbox guarded by engine.config)
            if name == "ask":
                if getattr(self.engine, 'config', {}).get('allow_ask', False):
                    return input(args[0] if args else "")
                if hasattr(self.engine, 'error_handler'):
                    self.engine.error_handler.report("SANDBOX", "ask() is disabled")
                return None

            if name == "random":
                import random
                if len(args) >= 2:
                    return random.randint(int(args[0]), int(args[1]))
                return random.random()

            # User-defined skills
            if name in self.engine.functions:
                return self.engine.call_skill(name, args)

        # Variable
        if expr in self.engine.variables:
            return self.engine.variables[expr]

        # List literal
        if expr.startswith("[") and expr.endswith("]") and hasattr(self.engine, 'list_core'):
            return self.engine.list_core.create_list(expr)

        # Math / string concatenation
        if any(op in expr for op in ['+', '-', '*', '/']):
            if '"' in expr:
                parts = re.split(r'\s*\+\s*(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', expr)
                res = ""
                for p in parts:
                    val = self.evaluate(p.strip())
                    res += str(self.engine.format_value(val) if hasattr(self.engine, 'format_value') else val)
                return res
            if hasattr(self.engine, 'math_core'):
                return self.engine.math_core.calculate(expr)

        # Variable-not-found error (only after trying special syntaxes)
        if not (is_num or expr.startswith('"')):
            if hasattr(self.engine, 'error_handler') and not any(op == expr for op in "+-*/"):
                self.engine.error_handler.report("VARIABLE", expr)

        return None
