from __future__ import annotations

import argparse
import json
import re
import os
import shutil
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, List

from . import __version__
from .lint import lint_source, format_source
from .host.modules import MODULE_ALLOWLIST
from .compiler import Compiler, CompiledProgram
from .vm import MellowVM, RunConfig


# ============================================================
# CLI policy (v1.0.3+)
# - Legacy UX stays supported.
# - Modern subcommands stay supported.
# - No breaking removals in v1.x (only additive).
# ============================================================

MODERN_CMDS = {"run", "check", "fmt", "init", "modules", "lsp", "help"}

def _start_lsp() -> int:
    from .lsp_server import start_lsp  # lazy import (pygls optional)
    return int(start_lsp() or 0)


def _supports_ansi() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.name != "nt":
        return True
    env = os.environ
    return any(k in env for k in ("WT_SESSION", "TERM", "ANSICON", "ConEmuANSI")) or (
        "vscode" in env.get("TERM_PROGRAM", "").lower()
    )


def _print_pretty_error(err: Exception, filename: str | None = None, source_lines: list[str] | None = None, *, use_color: bool | None = None) -> None:
    """Pretty error output inspired by Frinds (call stack + code frame)."""
    msg = str(err)
    if use_color is None:
        use_color = _supports_ansi()

    if use_color:
        RED = "\033[31m"; YELLOW = "\033[33m"; BLUE = "\033[34m"; DIM = "\033[2m"; BOLD = "\033[1m"; RESET = "\033[0m"
    else:
        RED = YELLOW = BLUE = DIM = BOLD = RESET = ""

    err_type = getattr(err, "error_type", None)
    line_no = getattr(err, "line_num", None)
    col = getattr(err, "col", None)
    fn = getattr(err, "filename", None) or filename

    if err_type:
        detail = getattr(err, "message", None) or msg
        if fn and line_no is not None:
            loc = f"{fn}:{line_no}" + (f":{col}" if col else "")
            print(f"{RED}Error:{RESET} {detail} (type={err_type})")
            print(f"{DIM}--> {loc}{RESET}")
        else:
            print(f"{RED}Error:{RESET} {detail} (type={err_type})")
    else:
        print(f"{RED}Error:{RESET} {msg}")

    trace = getattr(err, "trace", None)
    if trace:
        print(f"{BOLD}Call stack:{RESET}")
        for fr in reversed(trace):
            nm = fr.get("name", "<frame>")
            ffn = fr.get("filename", fn) or "<script>"
            ln = fr.get("line")
            cc = fr.get("col")
            loc = ffn if ln is None else f"{ffn}:{ln}" + (f":{cc}" if cc else "")
            print(f"  {BLUE}at{RESET} {nm} ({loc})")

    if line_no is None:
        m = re.search(r"at\s+(.+?):(\d+)(?::(\d+))?\s*:\s*", msg)
        if m:
            fn = m.group(1)
            line_no = int(m.group(2))
            if m.group(3):
                col = int(m.group(3))

    if not fn or not source_lines or line_no is None:
        return

    try:
        line_no = int(line_no)
    except Exception:
        return
    if line_no < 1 or line_no > len(source_lines):
        return

    col = int(col or 1)
    lo = max(1, line_no - 1)
    hi = min(len(source_lines), line_no + 1)
    for ln in range(lo, hi + 1):
        src = source_lines[ln - 1].rstrip("\n")
        prefix = ">" if ln == line_no else " "
        pfx = f"{YELLOW}{prefix}{RESET}" if ln == line_no else prefix
        print(f"{pfx} {ln:4d} | {src}")
        if ln == line_no:
            caret_col = max(1, min(col, len(src) + 1))
            print("  " + " " * 4 + " | " + " " * (caret_col - 1) + f"{YELLOW}^{RESET}")

def _prog() -> str:
    base = os.path.basename(sys.argv[0]) or "mellow"
    return os.path.splitext(base)[0]

def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")

def _json_print(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))

def _build_legacy_parser() -> argparse.ArgumentParser:
    prog = _prog()
    p = argparse.ArgumentParser(
        prog=prog,
        formatter_class=argparse.RawTextHelpFormatter,
        description=f"""MellowLang {__version__}
Friendly scripting language (game / AI focused)

Legacy usage:
  {prog} <script.mellow> [options]

Modern usage:
  {prog} run <script>
  {prog} check <script>
  {prog} fmt [-w] [--check] <files...>
  {prog} init <dir> [--force]
  {prog} modules [--json]
  {prog} lsp
""",
    )

    p.add_argument("script", nargs="?", help="Path to .mellow script")

    # runtime flags (legacy-compatible)
    p.add_argument("--check", dest="check_only", action="store_true",
                  help="Only check syntax/lint; do not run")
    p.add_argument("--modules", dest="list_modules", action="store_true",
                  help="List allowed host modules (same as: modules)")
    p.add_argument("--json", action="store_true", help="Output machine-readable JSON")

    mx = p.add_mutually_exclusive_group()
    mx.add_argument("--record", dest="record_path", help="Record deterministic replay log (.jsonl)")
    mx.add_argument("--replay", dest="replay_path", help="Replay deterministic log (.jsonl)")

    p.add_argument("--seed", type=int, help="Per-script seed")
    p.add_argument("--global-seed", type=int, help="Global base seed")

    p.add_argument("--allow-ask", action="store_true", help="Enable input()/ask() in sandbox")
    p.add_argument("--no-wait", action="store_true", help="Disable wait() in sandbox")
    p.add_argument("--color", action="store_true", help="Force colored errors")
    p.add_argument("--no-color", action="store_true", help="Disable colored errors")

    # compatibility flags (kept, but no longer required)
    p.add_argument("--engine", action="store_true", help="(Compat) Ignored in v1.0.3+")
    p.add_argument("--legacy", action="store_true", help="(Compat) Ignored in v1.0.3+")
    p.add_argument("--emit", dest="emit_name", help="(Compat) Reserved for .fds workflows")
    p.add_argument("--emit-args", dest="emit_args_raw", help="(Compat) JSON array args for --emit")

    p.add_argument("--lsp", action="store_true", help="Start Language Server (stdio)")
    p.add_argument("--version", action="version", version=f"{prog} {__version__}")
    return p

def _build_modern_parser() -> argparse.ArgumentParser:
    prog = _prog()
    p = argparse.ArgumentParser(
        prog=prog,
        formatter_class=argparse.RawTextHelpFormatter,
        description=f"""MellowLang {__version__}

Modern commands:
  {prog} run <file>            Run a script
  {prog} check <file>          Lint / syntax check
  {prog} fmt <files...>        Format source
  {prog} init <dir>            Create a project
  {prog} modules [--json]      List allowed host modules
  {prog} lsp                   Start language server (stdio)
""",
    )
    p.add_argument("--version", action="version", version=f"{prog} {__version__}")

    sub = p.add_subparsers(dest="cmd")

    pr = sub.add_parser("run", help="Run a script")
    pr.add_argument("file")
    pr.add_argument("--json", action="store_true")
    pr.add_argument("--record", dest="record_path")
    pr.add_argument("--replay", dest="replay_path")
    pr.add_argument("--seed", type=int)
    pr.add_argument("--global-seed", type=int)
    pr.add_argument("--allow-ask", action="store_true")
    pr.add_argument("--no-wait", action="store_true")

    pc = sub.add_parser("check", help="Check a script")
    pc.add_argument("file")
    pc.add_argument("--json", action="store_true")

    pf = sub.add_parser("fmt", help="Format files")
    pf.add_argument("files", nargs="+")
    pf.add_argument("-w", "--write", action="store_true")
    pf.add_argument("--check", action="store_true")

    pi = sub.add_parser("init", help="Create project from template")
    pi.add_argument("dir")
    pi.add_argument("--force", action="store_true")

    pm = sub.add_parser("modules", help="List allowed host modules")
    pm.add_argument("--json", action="store_true")

    sub.add_parser("lsp", help="Start language server")
    sub.add_parser("help", help="Show help")

    return p

# ----------------------------
# Command handlers
# ----------------------------

def _cmd_modules(json_out: bool) -> int:
    if json_out:
        _json_print(MODULE_ALLOWLIST)
        return 0
    print("Allowed host modules:")
    for mod in sorted(MODULE_ALLOWLIST.keys()):
        print(f"  - {mod}")
    return 0

def _cmd_check(file: str, json_out: bool) -> int:
    p = Path(file)
    if not p.exists():
        err = {"ok": False, "error": f"file not found: {p}"}
        if json_out:
            _json_print(err)
        else:
            print(f"error: {err['error']}")
        return 2
    src = _read_text(p)
    issues = lint_source(src)
    if json_out:
        _json_print({
            "ok": len(issues) == 0,
            "file": str(p),
            "issues": [asdict(it) if hasattr(it, "__dict__") else {"message": str(it)} for it in issues],
        })
    else:
        if not issues:
            print("✓ ok")
        else:
            for it in issues:
                # issue object in this codebase has kind/message/line (best-effort)
                kind = getattr(it, "kind", "issue")
                msg = getattr(it, "message", str(it))
                ln = getattr(it, "line", None)
                loc = f":{ln}" if ln else ""
                print(f"{kind}{loc}: {msg}")
    return 0 if not issues else 1

def _cmd_fmt(files: List[str], write: bool, check: bool) -> int:
    changed = 0
    for f in files:
        p = Path(f)
        if p.is_dir():
            for sub in p.rglob("*.mellow"):
                changed += _fmt_one(sub, write, check)
        else:
            changed += _fmt_one(p, write, check)
    return 0 if (not check or changed == 0) else 1

def _fmt_one(p: Path, write: bool, check: bool) -> int:
    if not p.exists():
        print(f"skip: {p} (not found)")
        return 0
    src = _read_text(p)
    out = format_source(src)
    if out == src:
        return 0
    if check:
        print(f"would format: {p}")
        return 1
    if write:
        p.write_text(out, encoding="utf-8")
        print(f"formatted: {p}")
        return 1
    sys.stdout.write(out)
    return 1

def _cmd_init(dest_dir: str, force: bool) -> int:
    dest = Path(dest_dir).resolve()
    template = Path(__file__).resolve().parents[2] / "project_template"
    if not template.exists():
        print("error: project_template not found.")
        return 2
    if dest.exists() and any(dest.iterdir()) and not force:
        print("error: destination not empty. Use --force.")
        return 2
    if dest.exists() and force:
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copytree(template, dest, dirs_exist_ok=True)
    print(f"✓ created project: {dest}")
    return 0

def _cmd_run(file: str, *, json_out: bool, record_path: str | None, replay_path: str | None,
             seed: int | None, global_seed: int | None, allow_ask: bool, no_wait: bool,
             color: bool, no_color: bool) -> int:
    p = Path(file)
    if not p.exists():
        err = {"ok": False, "error": f"file not found: {p}"}
        if json_out:
            _json_print(err)
        else:
            print(f"error: {err['error']}")
        return 2

    src = _read_text(p)

    comp = Compiler()
    program = comp.compile(src, filename=str(p))

    vm = MellowVM()
    cfg = RunConfig(
        seed=seed,
        global_seed=global_seed,
        record_path=record_path,
        replay_path=replay_path,
        allow_ask=allow_ask,
        allow_wait=not no_wait,
    )

    # error color policy is currently handled by runtime; here we only ensure ANSI support isn't forced wrongly.
    # (kept for CLI compatibility)
    _ = (color, no_color)

    try:
        result = vm.run(program, config=cfg)
        if json_out:
            _json_print({"ok": True, "result": result})
        return 0
    except Exception as e:
        if json_out:
            _json_print({"ok": False, "error": str(e)})
        else:
            use_color = True if color else (False if no_color else None)
            _print_pretty_error(e, filename=str(p), source_lines=src.splitlines(True), use_color=use_color)
        return 1

# ----------------------------
# Main
# ----------------------------

def main(argv: List[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)

    # mode selection
    if argv and argv[0] in MODERN_CMDS:
        p = _build_modern_parser()
        ns = p.parse_args(argv)
        cmd = ns.cmd
        if cmd in (None, "help"):
            p.print_help()
            return 0
        if cmd == "modules":
            return _cmd_modules(ns.json)
        if cmd == "check":
            return _cmd_check(ns.file, ns.json)
        if cmd == "fmt":
            return _cmd_fmt(ns.files, ns.write, ns.check)
        if cmd == "init":
            return _cmd_init(ns.dir, ns.force)
        if cmd == "lsp":
            return int(_start_lsp() or 0)
        if cmd == "run":
            return _cmd_run(
                ns.file,
                json_out=ns.json,
                record_path=getattr(ns, "record_path", None),
                replay_path=getattr(ns, "replay_path", None),
                seed=getattr(ns, "seed", None),
                global_seed=getattr(ns, "global_seed", None),
                allow_ask=getattr(ns, "allow_ask", False),
                no_wait=getattr(ns, "no_wait", False),
                color=False,
                no_color=False,
            )
        p.print_help()
        return 2

    # legacy mode
    p = _build_legacy_parser()
    ns = p.parse_args(argv)

    if getattr(ns, "lsp", False):
        return int(_start_lsp() or 0)

    if getattr(ns, "list_modules", False):
        return _cmd_modules(bool(ns.json))

    if not ns.script:
        p.print_help()
        return 2

    if getattr(ns, "check_only", False):
        return _cmd_check(ns.script, bool(ns.json))

    return _cmd_run(
        ns.script,
        json_out=bool(ns.json),
        record_path=getattr(ns, "record_path", None),
        replay_path=getattr(ns, "replay_path", None),
        seed=getattr(ns, "seed", None),
        global_seed=getattr(ns, "global_seed", None),
        allow_ask=getattr(ns, "allow_ask", False),
        no_wait=getattr(ns, "no_wait", False),
        color=getattr(ns, "color", False),
        no_color=getattr(ns, "no_color", False),
    )
