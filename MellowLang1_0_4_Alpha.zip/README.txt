MellowLang v1.0.4 (Public Alpha)

Quick start:
1) unzip
2) open terminal here
3) run: mellow examples/hello.mellow

Docs:
- docs/SYNTAX_REFERENCE.md
- docs/STYLE_GUIDE.md

Status:
- Public Alpha
- Syntax may change