# MellowLang Syntax Reference (v1.0.3)



## Recommended Modern Syntax (v1.0.3)

MellowLang supports several aliases for friendliness, but for tutorials and team codebases we recommend:

- Use **`print(...)`** instead of `show(...)`
- Use **`input(...)`** instead of `ask(...)` (note: may require `--allow-ask`)
- Prefer **Python-like `for` / `while`** loop styles when possible

Older/alternative forms remain supported for compatibility.

---

ดูไฟล์ `MELLOWLANG_User_Manual.md` สำหรับคู่มือเต็ม
