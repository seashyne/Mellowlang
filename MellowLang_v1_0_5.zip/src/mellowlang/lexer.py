
# frinds/lexer.py
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class Token:
    type: str
    value: str
    pos: int

KEYWORDS = {
    "keep","show","precision","check","also","else","loop","skill","return",
    "stop","wait","save","load","into","put","in","and","or","not","true","false","none","null"
}

TWO_CHAR = {"==","!=",">=","<="}
SINGLE = set("()+-*/=,:[]{}<>")

def lex_expr(src: str) -> List[Token]:
    tokens: List[Token] = []
    i = 0
    n = len(src)
    while i < n:
        ch = src[i]
        if ch.isspace():
            i += 1
            continue
        if ch == '"':
            start = i
            i += 1
            buf = []
            while i < n:
                if src[i] == '\\' and i+1 < n:
                    buf.append(src[i+1])
                    i += 2
                    continue
                if src[i] == '"':
                    i += 1
                    break
                buf.append(src[i])
                i += 1
            tokens.append(Token("STRING", "".join(buf), start))
            continue
        # number (int/float) including leading -
        if ch.isdigit() or (ch == '.' and i+1 < n and src[i+1].isdigit()):
            start = i
            has_dot = False
            while i < n and (src[i].isdigit() or src[i] == '.'):
                if src[i] == '.':
                    if has_dot: break
                    has_dot = True
                i += 1
            tokens.append(Token("NUMBER", src[start:i], start))
            continue
        # identifier / keyword
        if ch.isalpha() or ch == '_':
            start = i
            i += 1
            while i < n and (src[i].isalnum() or src[i] == '_'):
                i += 1
            text = src[start:i]
            ttype = "KW" if text.lower() in KEYWORDS else "IDENT"
            tokens.append(Token(ttype, text, start))
            continue
        # operators
        if i+1 < n and src[i:i+2] in TWO_CHAR:
            tokens.append(Token("OP", src[i:i+2], i))
            i += 2
            continue
        if ch in SINGLE:
            ttype = "OP" if ch in "+-*/=<>:" else "PUNC"
            # keep uniform: treat all as OP/PUNC by value
            tokens.append(Token("SYMBOL", ch, i))
            i += 1
            continue
        # unknown char -> treat as symbol
        tokens.append(Token("SYMBOL", ch, i))
        i += 1
    tokens.append(Token("EOF","", n))
    return tokens
