
# frinds/compiler.py (v2.2)
from __future__ import annotations
from typing import List, Dict, Any, Tuple
from ..constants import Op
from ..error_core import MellowLangRuntimeError
from ..ast import *
from ..parser import parse_program, ParseError

class Compiler:
    """
    v2.2: Parser/AST based compiler.
    - Parses full program into AST (no regex parsing of expressions)
    - Compiles AST -> bytecode for MellowLangVM
    """
    def __init__(self):
        self.bytecode: List[tuple] = []
        self.line_map: List[int] = []  # pc -> source line
        self.col_map: List[int] = []  # pc -> source column (1-indexed)
        self._cur_line = 0
        self._cur_col = 1
        # name -> {address:int, param_count:int}
        self.functions: Dict[str, Dict[str, Any]] = {}
        # event_name -> {address:int, param_count:int}
        self.events: Dict[str, Dict[str, Any]] = {}
        self._tmp_id = 0
        self._loop_stack: List[dict] = []

    def emit(self, instr: tuple):
        self.bytecode.append(instr)
        self.line_map.append(int(self._cur_line or 0))
        self.col_map.append(int(self._cur_col or 1))

    def compile(self, lines: List[str], *, filename: str | None = None) -> List[tuple]:
        prog = parse_program(lines, filename=filename)
        self.bytecode = []
        self.line_map = []
        self.col_map = []
        self.functions = {}
        self.events = {}
        self._cur_line = 0
        self._cur_col = 1
        self._loop_stack = []
        self._compile_program(prog)
        self.emit((Op.HALT,))
        return self.bytecode

    # ---------- Program/Statement compilation ----------

    def _compile_program(self, prog: Program):
        # 1) Emit placeholders to jump over skill bodies declared at top-level.
        # We compile in-order: statements. For each SkillDef, we jump over its body.
        for stmt in prog.body:
            self._compile_stmt(stmt)

    def _compile_stmt(self, s: Stmt):
        self._cur_line = int(getattr(s, "_line", self._cur_line) or 0)
        self._cur_col  = int(getattr(s, "_col", self._cur_col) or 1)
        if isinstance(s, KeepStmt):
            self._compile_expr(s.expr)
            self.emit((Op.STORE_KEEP, s.name))
        elif isinstance(s, KeepMultiStmt):
            # Parallel multi-assign: evaluate all RHS first, then assign.
            # This enables safe swaps: keep a,b = b,a
            if len(s.names) != len(s.exprs):
                raise RuntimeError("KeepMultiStmt: names/exprs length mismatch")
            for ex in s.exprs:
                self._compile_expr(ex)
            for name in reversed(s.names):
                self.emit((Op.STORE_KEEP, name))
        elif isinstance(s, AssignStmt):
            # Parallel multi-assign for normal variables.
            if len(s.names) != len(s.exprs):
                raise RuntimeError("AssignStmt: names/exprs length mismatch")
            for ex in s.exprs:
                self._compile_expr(ex)
            for name in reversed(s.names):
                self.emit((Op.STORE_AUTO, name))
        elif isinstance(s, ExprStmt):
            self._compile_expr(s.expr)
            self.emit((Op.POP,))
        elif isinstance(s, ShowStmt):
            self._compile_expr(s.expr)
            self.emit((Op.PRINT,))
        elif isinstance(s, PrecisionStmt):
            self._compile_expr(s.expr)
            self.emit((Op.SHOW_PREC,))
        elif isinstance(s, StopStmt):
            self.emit((Op.STOP,))
        elif isinstance(s, WaitStmt):
            self._compile_expr(s.expr)
            self.emit((Op.WAIT,))
        elif isinstance(s, PutStmt):
            # push item then load list then append
            self._compile_expr(s.item_expr)
            self.emit((Op.LOAD, s.list_name))
            self.emit((Op.LIST_PUT,))
        elif isinstance(s, SaveStmt):
            # save <value_expr> into <filename_expr>
            self._compile_expr(s.filename_expr)
            self._compile_expr(s.value_expr)
            self.emit((Op.SAVE_VAL,))  # store top value into file name below
        elif isinstance(s, LoadStmt):
            self._compile_expr(s.filename_expr)
            self.emit((Op.LOAD_F, s.var_name))
        elif isinstance(s, ReturnStmt):
            if s.expr is None:
                self.emit((Op.PUSH, None))
            else:
                self._compile_expr(s.expr)
            self.emit((Op.RETURN,))
        elif isinstance(s, BreakStmt):
            if not self._loop_stack:
                ln = getattr(s, "_line", None)
                col = getattr(s, "_col", None)
                raise MellowLangRuntimeError("SYNTAX", "break can only be used inside a loop", ln, col=col)
            ctx = self._loop_stack[-1]
            ctx["break_jumps"].append(len(self.bytecode))
            self.emit((Op.JUMP, None))
        elif isinstance(s, ContinueStmt):
            if not self._loop_stack:
                ln = getattr(s, "_line", None)
                col = getattr(s, "_col", None)
                raise MellowLangRuntimeError("SYNTAX", "continue can only be used inside a loop", ln, col=col)
            ctx = self._loop_stack[-1]
            ctx["continue_jumps"].append(len(self.bytecode))
            self.emit((Op.JUMP, None))
        elif isinstance(s, TryStmt):
            self._compile_try(s)
        elif isinstance(s, SkillDef):
            # Jump over function body in main execution
            jmp_idx = len(self.bytecode)
            self.emit((Op.JUMP, None))

            start_addr = len(self.bytecode)
            self.functions[s.name] = {"address": start_addr, "param_count": len(s.params), "params": s.params}

            # Move arguments from stack to locals (reverse)
            for p in reversed(s.params):
                self.emit((Op.ARG, p))

            for st in s.body:
                self._compile_stmt(st)

            # implicit return none
            self.emit((Op.PUSH, None))
            self.emit((Op.RETURN,))

            # patch jump
            self.bytecode[jmp_idx] = (Op.JUMP, len(self.bytecode))

        elif isinstance(s, OnDef):
            # Jump over event handler body in main execution
            jmp_idx = len(self.bytecode)
            self.emit((Op.JUMP, None))

            start_addr = len(self.bytecode)
            self.events[s.event] = {"address": start_addr, "param_count": len(s.params), "params": s.params}

            for p in reversed(s.params):
                self.emit((Op.ARG, p))

            for st in s.body:
                self._compile_stmt(st)

            # implicit return none
            self.emit((Op.PUSH, None))
            self.emit((Op.RETURN,))

            self.bytecode[jmp_idx] = (Op.JUMP, len(self.bytecode))
        elif isinstance(s, IfGroup):
            self._compile_ifgroup(s)
        elif isinstance(s, LoopWhile):
            self._compile_loop_while(s)
        elif isinstance(s, LoopForEach):
            self._compile_loop_foreach(s)
        elif isinstance(s, LoopForMap):
            self._compile_loop_formap(s)
        elif isinstance(s, DoBlock):
            for st in s.body:
                self._compile_stmt(st)
        elif isinstance(s, LoopForRange):
            self._compile_loop_forrange(s)
        elif isinstance(s, RepeatUntil):
            self._compile_repeat_until(s)
        elif isinstance(s, LoopCount):
            self._compile_loop_count(s)
        else:
            raise RuntimeError(f"Unknown stmt: {s}")

    def _compile_ifgroup(self, ig: IfGroup):
        """Compile check/also/else (and if/elif alias)."""
        end_jumps: List[int] = []
        next_patch: List[int] = []  # list of JIF indices to patch to next branch

        for (cond, block) in ig.branches:
            # patch previous branch-false jumps to here
            cur_addr = len(self.bytecode)
            for jif_idx in next_patch:
                self.bytecode[jif_idx] = (Op.JIF, cur_addr)
            next_patch = []

            self._compile_expr(cond)
            jif_idx = len(self.bytecode)
            self.emit((Op.JIF, None))  # jump to next branch (patched later)
            next_patch.append(jif_idx)

            for st in block:
                self._compile_stmt(st)

            end_jumps.append(len(self.bytecode))
            self.emit((Op.JUMP, None))

        # else block entry
        else_addr = len(self.bytecode)
        for jif_idx in next_patch:
            self.bytecode[jif_idx] = (Op.JIF, else_addr)

        if ig.else_block is not None:
            for st in ig.else_block:
                self._compile_stmt(st)

        end_addr = len(self.bytecode)
        for j in end_jumps:
            self.bytecode[j] = (Op.JUMP, end_addr)

    def _compile_loop_while(self, lp: LoopWhile):
        loop_start = len(self.bytecode)
        ctx = {"break_jumps": [], "continue_jumps": []}
        self._loop_stack.append(ctx)
        self._compile_expr(lp.cond)
        jif_idx = len(self.bytecode)
        self.emit((Op.JIF, None))
        for st in lp.body:
            self._compile_stmt(st)
        self.emit((Op.JUMP, loop_start))
        end_addr = len(self.bytecode)
        self.bytecode[jif_idx] = (Op.JIF, end_addr)

        # patch break/continue
        for j in ctx["continue_jumps"]:
            self.bytecode[j] = (Op.JUMP, loop_start)
        for j in ctx["break_jumps"]:
            self.bytecode[j] = (Op.JUMP, end_addr)
        self._loop_stack.pop()


    
    def _compile_repeat_until(self, rp: RepeatUntil):
        loop_start = len(self.bytecode)
        ctx = {"break_jumps": [], "continue_jumps": []}
        self._loop_stack.append(ctx)

        for st in rp.body:
            self._compile_stmt(st)

        # until condition (stop when cond is true)
        self._compile_expr(rp.cond)
        jif_idx = len(self.bytecode)
        # if condition is false -> jump back to start
        self.emit((Op.JIF, loop_start))

        end_addr = len(self.bytecode)
        # patch break/continue
        for j in ctx["continue_jumps"]:
            self.bytecode[j] = (Op.JUMP, loop_start)
        for j in ctx["break_jumps"]:
            self.bytecode[j] = (Op.JUMP, end_addr)
        self._loop_stack.pop()

    def _compile_loop_count(self, lp: LoopCount):
        # loop count < limit:
        idx_var = self._new_tmp("__count")
        limit_var = self._new_tmp("__limit")

        # idx=0
        self.emit((Op.PUSH, 0))
        self.emit((Op.STORE, idx_var))
        # limit = expr
        self._compile_expr(lp.limit)
        self.emit((Op.STORE, limit_var))

        ctx = {"break_jumps": [], "continue_jumps": []}
        self._loop_stack.append(ctx)

        loop_start = len(self.bytecode)

        # condition: idx < limit
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.LOAD, limit_var))
        self.emit((Op.COMPARE, "<"))
        jif_idx = len(self.bytecode)
        self.emit((Op.JIF, None))

        # expose 'count' to user each iteration
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.STORE, "count"))

        for st in lp.body:
            self._compile_stmt(st)

        incr_addr = len(self.bytecode)
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.PUSH, 1))
        self.emit((Op.ADD,))
        self.emit((Op.STORE, idx_var))

        self.emit((Op.JUMP, loop_start))
        end_addr = len(self.bytecode)
        self.bytecode[jif_idx] = (Op.JIF, end_addr)

        for j in ctx["continue_jumps"]:
            self.bytecode[j] = (Op.JUMP, incr_addr)
        for j in ctx["break_jumps"]:
            self.bytecode[j] = (Op.JUMP, end_addr)
        self._loop_stack.pop()


    def _compile_loop_forrange(self, lp: LoopForRange):
        # numeric for: for i = start, end, step (inclusive end, Lua-like)
        i_var = lp.var_name
        start_tmp = self._new_tmp("__for_start")
        end_tmp = self._new_tmp("__for_end")
        step_tmp = self._new_tmp("__for_step")

        # evaluate start/end once
        self._compile_expr(lp.start)
        self.emit((Op.STORE, start_tmp))
        self._compile_expr(lp.end)
        self.emit((Op.STORE, end_tmp))

        # step default: if omitted -> +1 when start<=end else -1
        if lp.step is None:
            cond_tmp = self._new_tmp("__for_cond")
            self.emit((Op.LOAD, start_tmp))
            self.emit((Op.LOAD, end_tmp))
            self.emit((Op.COMPARE, "<="))
            self.emit((Op.STORE, cond_tmp))

            # if not cond -> step = -1 else step = 1
            self.emit((Op.LOAD, cond_tmp))
            jif_idx = len(self.bytecode)
            self.emit((Op.JIF, None))  # false => jump to set -1
            self.emit((Op.PUSH, 1))
            self.emit((Op.STORE, step_tmp))
            jmp_end = len(self.bytecode)
            self.emit((Op.JUMP, None))
            neg_addr = len(self.bytecode)
            self.bytecode[jif_idx] = (Op.JIF, neg_addr)
            self.emit((Op.PUSH, -1))
            self.emit((Op.STORE, step_tmp))
            end_addr = len(self.bytecode)
            self.bytecode[jmp_end] = (Op.JUMP, end_addr)
        else:
            self._compile_expr(lp.step)
            self.emit((Op.STORE, step_tmp))

        # i = start
        self.emit((Op.LOAD, start_tmp))
        self.emit((Op.STORE, i_var))

        ctx = {"break_jumps": [], "continue_jumps": []}
        self._loop_stack.append(ctx)

        loop_start = len(self.bytecode)

        # if step > 0: i <= end else: i >= end
        self.emit((Op.LOAD, step_tmp))
        self.emit((Op.PUSH, 0))
        self.emit((Op.COMPARE, ">"))
        sign_jif = len(self.bytecode)
        self.emit((Op.JIF, None))  # false => negative branch

        # positive branch
        self.emit((Op.LOAD, i_var))
        self.emit((Op.LOAD, end_tmp))
        self.emit((Op.COMPARE, "<="))
        cond_jif_pos = len(self.bytecode)
        self.emit((Op.JIF, None))
        jmp_to_body = len(self.bytecode)
        self.emit((Op.JUMP, None))

        # negative branch
        neg_branch = len(self.bytecode)
        self.bytecode[sign_jif] = (Op.JIF, neg_branch)

        self.emit((Op.LOAD, i_var))
        self.emit((Op.LOAD, end_tmp))
        self.emit((Op.COMPARE, ">="))
        cond_jif_neg = len(self.bytecode)
        self.emit((Op.JIF, None))
        jmp_to_body2 = len(self.bytecode)
        self.emit((Op.JUMP, None))

        # body entry
        body_addr = len(self.bytecode)
        self.bytecode[jmp_to_body] = (Op.JUMP, body_addr)
        self.bytecode[jmp_to_body2] = (Op.JUMP, body_addr)

        for st in lp.body:
            self._compile_stmt(st)

        incr_addr = len(self.bytecode)

        # i = i + step
        self.emit((Op.LOAD, i_var))
        self.emit((Op.LOAD, step_tmp))
        self.emit((Op.ADD,))
        self.emit((Op.STORE, i_var))

        self.emit((Op.JUMP, loop_start))

        end_loop = len(self.bytecode)
        self.bytecode[cond_jif_pos] = (Op.JIF, end_loop)
        self.bytecode[cond_jif_neg] = (Op.JIF, end_loop)

        for j in ctx["continue_jumps"]:
            self.bytecode[j] = (Op.JUMP, incr_addr)
        for j in ctx["break_jumps"]:
            self.bytecode[j] = (Op.JUMP, end_loop)
        self._loop_stack.pop()

    def _new_tmp(self, prefix="__tmp") -> str:
        self._tmp_id += 1
        return f"{prefix}{self._tmp_id}"

    def _compile_loop_foreach(self, lp: LoopForEach):
        # foreach var in iterable:
        iter_var = self._new_tmp("__iter")
        idx_var = self._new_tmp("__idx")

        # iter = iterable
        self._compile_expr(lp.iterable)
        self.emit((Op.STORE, iter_var))
        # idx = 0
        self.emit((Op.PUSH, 0))
        self.emit((Op.STORE, idx_var))

        ctx = {"break_jumps": [], "continue_jumps": []}
        self._loop_stack.append(ctx)

        loop_start = len(self.bytecode)

        # condition: idx < len(iter)
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.LOAD, iter_var))
        self.emit((Op.LEN,))
        self.emit((Op.COMPARE, "<"))
        jif_idx = len(self.bytecode)
        self.emit((Op.JIF, None))

        # bind loop var = iter[idx]
        self.emit((Op.LOAD, iter_var))
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.GETITEM,))
        self.emit((Op.STORE, lp.var_name))

        for st in lp.body:
            self._compile_stmt(st)

        incr_addr = len(self.bytecode)

        # idx = idx + 1
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.PUSH, 1))
        self.emit((Op.ADD,))
        self.emit((Op.STORE, idx_var))

        self.emit((Op.JUMP, loop_start))
        end_addr = len(self.bytecode)
        self.bytecode[jif_idx] = (Op.JIF, end_addr)

        # patch break/continue
        for j in ctx["continue_jumps"]:
            self.bytecode[j] = (Op.JUMP, incr_addr)
        for j in ctx["break_jumps"]:
            self.bytecode[j] = (Op.JUMP, end_addr)
        self._loop_stack.pop()

        # patch break/continue


    def _compile_loop_formap(self, lp: LoopForMap):
        """loop k, v in map_expr: ... end

        Compiles by materializing keys list via std.map.keys (no copy of values),
        then v is fetched via std.map.get per key.
        """
        map_var = self._new_tmp("__map")
        keys_var = self._new_tmp("__keys")
        idx_var = self._new_tmp("__idx")

        # map = iterable
        self._compile_expr(lp.iterable)
        self.emit((Op.STORE, map_var))

        # keys = std.map.keys(map)
        self.emit((Op.PUSH, "std.map.keys"))
        self.emit((Op.LOAD, map_var))
        self.emit((Op.SYSCALL, 1))
        self.emit((Op.STORE, keys_var))

        # idx = 0
        self.emit((Op.PUSH, 0))
        self.emit((Op.STORE, idx_var))

        ctx = {"break_jumps": [], "continue_jumps": []}
        self._loop_stack.append(ctx)

        loop_start = len(self.bytecode)

        # condition: idx < len(keys)
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.LOAD, keys_var))
        self.emit((Op.LEN,))
        self.emit((Op.COMPARE, "<"))
        jif_idx = len(self.bytecode)
        self.emit((Op.JIF, None))

        # key = keys[idx]
        self.emit((Op.LOAD, keys_var))
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.GETITEM,))
        self.emit((Op.STORE, lp.key_name))

        # value = std.map.get(map, key)
        self.emit((Op.PUSH, "std.map.get"))
        self.emit((Op.LOAD, map_var))
        self.emit((Op.LOAD, lp.key_name))
        self.emit((Op.SYSCALL, 2))
        self.emit((Op.STORE, lp.value_name))

        for st in lp.body:
            self._compile_stmt(st)

        incr_addr = len(self.bytecode)
        self.emit((Op.LOAD, idx_var))
        self.emit((Op.PUSH, 1))
        self.emit((Op.ADD,))
        self.emit((Op.STORE, idx_var))
        self.emit((Op.JUMP, loop_start))

        end_addr = len(self.bytecode)
        self.bytecode[jif_idx] = (Op.JIF, end_addr)

        for j in ctx["continue_jumps"]:
            self.bytecode[j] = (Op.JUMP, incr_addr)
        for j in ctx["break_jumps"]:
            self.bytecode[j] = (Op.JUMP, end_addr)
        self._loop_stack.pop()

    def _compile_try(self, ts: TryStmt):
        """Compile try/catch/finally using Op.TRY/Op.ENDTRY."""
        has_catch = ts.catch_body is not None and ts.catch_name is not None
        has_finally = ts.finally_body is not None

        if not (has_catch or has_finally):
            for st in ts.try_body:
                self._compile_stmt(st)
            return

        try_idx = len(self.bytecode)
        # placeholders: catch_pc, finally_pc, err_name
        self.emit((Op.TRY, None, None, ts.catch_name if has_catch else None))

        for st in ts.try_body:
            self._compile_stmt(st)

        # normal exit from try
        self.emit((Op.ENDTRY,))
        jmp_to_finally_from_try = len(self.bytecode)
        self.emit((Op.JUMP, None))

        catch_pc = len(self.bytecode)
        if has_catch:
            for st in ts.catch_body or []:
                self._compile_stmt(st)
        jmp_to_finally_from_catch = None
        if has_catch:
            jmp_to_finally_from_catch = len(self.bytecode)
            self.emit((Op.JUMP, None))

        finally_pc = len(self.bytecode)
        if has_finally:
            for st in ts.finally_body or []:
                self._compile_stmt(st)

        end_pc = len(self.bytecode)

        # patch TRY placeholders
        if not has_catch:
            catch_pc = finally_pc
        if not has_finally:
            finally_pc = end_pc
        self.bytecode[try_idx] = (Op.TRY, catch_pc, finally_pc, ts.catch_name if has_catch else None)

        # patch jumps to finally
        self.bytecode[jmp_to_finally_from_try] = (Op.JUMP, finally_pc)
        if jmp_to_finally_from_catch is not None:
            self.bytecode[jmp_to_finally_from_catch] = (Op.JUMP, finally_pc)

    # ---------- Expression compilation ----------

    def _compile_expr(self, e: Expr):
        if isinstance(e, Literal):
            self.emit((Op.PUSH, e.value))
        elif isinstance(e, Var):
            self.emit((Op.LOAD, e.name))
        elif isinstance(e, UnaryOp):
            self._compile_expr(e.expr)
            if e.op == "not":
                self.emit((Op.BOOL_NOT,))
            elif e.op == "-":
                self.emit((Op.PUSH, -1))
                self.emit((Op.MUL,))
            else:
                raise RuntimeError(f"Unknown unary op {e.op}")
        elif isinstance(e, BinaryOp):
            # boolean short-circuit could be added later; v2.2 evaluates both sides
            self._compile_expr(e.left)
            self._compile_expr(e.right)
            op = e.op
            if op == "+": self.emit((Op.ADD,))
            elif op == "-": self.emit((Op.SUB,))
            elif op == "*": self.emit((Op.MUL,))
            elif op == "/": self.emit((Op.DIV,))
            elif op in ("==","!=",">","<",">=","<="):
                self.emit((Op.COMPARE, op))
            elif op == "and":
                self.emit((Op.BOOL_AND,))
            elif op == "or":
                self.emit((Op.BOOL_OR,))
            else:
                raise RuntimeError(f"Unknown binary op {op}")
        elif isinstance(e, Call):
            # builtins handled by VM: random, ask (if enabled), call(syscall)
            if e.name == "global_seed":
                # global_seed(n)
                if len(e.args) != 1:
                    raise RuntimeError("global_seed() expects 1 arg")
                self._compile_expr(e.args[0])
                self.emit((Op.GLOBAL_SEED,))
                return
            if e.name == "seed":
                # seed(n)
                if len(e.args) != 1:
                    raise RuntimeError("seed() expects 1 arg")
                self._compile_expr(e.args[0])
                self.emit((Op.SEED,))
                return
            if e.name == "rand":
                # rand() -> float [0,1)
                if len(e.args) != 0:
                    raise RuntimeError("rand() expects 0 args")
                self.emit((Op.RANDFLOAT,))
                return
            if e.name == "randi":
                # randi(lo, hi) -> int inclusive
                if len(e.args) != 2:
                    raise RuntimeError("randi() expects 2 args")
                for a in e.args:
                    self._compile_expr(a)
                self.emit((Op.RANDOM,))
                return
            if e.name == "random":
                # expect 2 args
                for a in e.args:
                    self._compile_expr(a)
                self.emit((Op.RANDOM,))
                return
            if e.name in ("rand_int","random_int"):
                for a in e.args:
                    self._compile_expr(a)
                self.emit((Op.RANDOM,))
                return
            if e.name in ("rand_float","random_float"):
                # no args
                self.emit((Op.RANDFLOAT,))
                return
            if e.name in ("ask","input"):
                for a in e.args:
                    self._compile_expr(a)
                self.emit((Op.ASK,))
                return
            if e.name == "call":
                # call("x.y", arg1, arg2, ...)
                if not e.args:
                    self.emit((Op.PUSH, None))
                    return
                # first arg is name
                self._compile_expr(e.args[0])
                # remaining args as list
                for a in e.args[1:]:
                    self._compile_expr(a)
                self.emit((Op.SYSCALL, len(e.args)-1))
                return

            # get("math") / lib("math") -> returns a cached module map (allowlisted)
            if e.name in ("get", "lib"):
                # get(name)
                self.emit((Op.PUSH, "sys.get"))
                for a in e.args:
                    self._compile_expr(a)
                self.emit((Op.SYSCALL, len(e.args)))
                return

            # stdlib helper calls (compile to SYSCALL)
            STDLIB_SYSCALLS = {
                # list
                "list_push": "std.list.push",
                "list_pop": "std.list.pop",
                "list_len": "std.list.len",
                "list_insert": "std.list.insert",
                "list_remove": "std.list.remove",
                "list_has": "std.list.has",
                "list_sort": "std.list.sort",
                # map
                "map_get": "std.map.get",
                "map_set": "std.map.set",
                "map_keys": "std.map.keys",
                "map_values": "std.map.values",
                "map_has": "std.map.has",
                # string helpers (aliases: str_* and string_*)
                "str_len": "std.string.len",
                "str_lower": "std.string.lower",
                "str_upper": "std.string.upper",
                "str_trim": "std.string.trim",
                "str_replace": "std.string.replace",
                "str_find": "std.string.find",
                "str_split": "std.string.split",
                "str_join": "std.string.join",
                "string_len": "std.string.len",
                "string_lower": "std.string.lower",
                "string_upper": "std.string.upper",
                # json
                "json_encode": "std.json.encode",
                "json_decode": "std.json.decode",
                # range
                "range": "std.range",

                # math
                "abs": "std.math.abs",
                "min": "std.math.min",
                "max": "std.math.max",
                "floor": "std.math.floor",
                "ceil": "std.math.ceil",
                "round": "std.math.round",
                "sqrt": "std.math.sqrt",
                "pow": "std.math.pow",
                "sin": "std.math.sin",
                "cos": "std.math.cos",
                "tan": "std.math.tan",
                "atan2": "std.math.atan2",
                "clamp": "std.math.clamp",
                "lerp": "std.math.lerp",
                # vectors (fast game helpers)
                "vec2": "std.math.vec2",
                "vec3": "std.math.vec3",
                # generic vectors (multi-dim)
                "vec": "std.math.vector",
                "vector": "std.math.vector",
                "vec_add": "std.math.vec_add",
                "vec_sub": "std.math.vec_sub",
                "vec_mul": "std.math.vec_mul",
                "vec_dot": "std.math.vec_dot",
                "vec_len": "std.math.vec_len",
                "vec_norm": "std.math.vec_norm",
                "vec_dist": "std.math.vec_dist",
                "vec_lerp": "std.math.vec_lerp",
                "vec_limit": "std.math.vec_limit",
                "vec_dim": "std.math.vec_dim",
                "vec_axis": "std.math.vec_axis",
                "vec_with": "std.math.vec_with",
                # time
                "time_now": "std.time.now",
                "time_unix": "std.time.unix",
                "time_ms": "std.time.ms",
            }
            if e.name in STDLIB_SYSCALLS:
                self.emit((Op.PUSH, STDLIB_SYSCALLS[e.name]))
                for a in e.args:
                    self._compile_expr(a)
                self.emit((Op.SYSCALL, len(e.args)))
                return

            # user defined skill call
            for a in e.args:
                self._compile_expr(a)
            self.emit((Op.CALL, e.name, len(e.args)))
        elif isinstance(e, Index):
            self._compile_expr(e.target)
            self._compile_expr(e.index)
            self.emit((Op.GETITEM,))
        elif isinstance(e, ListLiteral):
            # build list runtime (supports vars/nested)
            for item in e.items:
                self._compile_expr(item)
            self.emit((Op.BUILD_LIST, len(e.items)))
        elif isinstance(e, MapLiteral):
            # keys and values
            for k, v in e.pairs:
                self._compile_expr(k)
                self._compile_expr(v)
            self.emit((Op.BUILD_MAP, len(e.pairs)))
        else:
            raise RuntimeError(f"Unknown expr: {e}")
