# MellowLang v3.5.0 User Manual (Sandbox VM)

> เป้าหมาย: เขียนสคริปต์เกม/AI ให้เร็ว เข้าใจง่าย และ deterministic (replay ได้)

## 1) เริ่มต้นรัน

```bash
python main.py test/v3_5_0_test_vector.frinds
```

ดูเวอร์ชัน:
```bash
python main.py --version
```

## 2) โครงสร้างภาษา (Block)

MellowLang เปิดบล็อกด้วย `:` และปิดด้วย `end`

```frinds
if x > 0:
    show("hi")
end
```

## 3) Loop

### 3.1 Numeric for (Lua style)
```frinds
for i = 1, 10, 2 do
    show(i)
end
```

### 3.2 range iterator (ไม่สร้าง list)
```frinds
loop i in range(0, 10, 2):
    show(i)
end
```

### 3.3 map loop
```frinds
keep m = {"a": 1, "b": 2}
loop k, v in m:
    show(k)
end
```

## 4) break / continue
ใช้ได้ในทุก loop และจะ error ชัดเจนถ้าใช้ผิดที่

## 5) keep (เอกลักษณ์หลักของ MellowLang)

`keep` คือ state แบบ persistent ของสคริปต์ (เหมาะกับเกม/AI)

```frinds
keep score = 0
score = score + 1
show(score)
```

รองรับ multi-assign:
```frinds
keep a, b = 1, 2
a, b = b, a
```

## 6) Deterministic Random

ต่อสคริปต์:
```frinds
seed(123)
show(randi(1, 10))
```

ทั้ง VM (ใหม่):
```frinds
global_seed(999)
```

- `global_seed(n)` ตั้ง base seed ของ VM (best-effort persist)
- สคริปต์แต่ละไฟล์จะ derive seed แยกกันเพื่อไม่แย่ง RNG
- ยัง override เฉพาะสคริปต์ได้ด้วย `seed(n)`

## 7) Vector (vec2/vec3 และ vec/vector หลายมิติ)

ยังใช้ `vec2/vec3` ได้ตามเดิม:
```frinds
p = vec2(1, 2)
q = vec3(1, 2, 3)
```

เพิ่ม `vec(...)` และ `vector(...)` (alias กัน):
```frinds
v2 = vec(1, 2)
v3 = vector(1, 2, 3)
v4 = vec(1, 2, 3, 4)
```

Helpers หลัก (ใช้ได้ทั้ง vec2/vec3/vecN):
- `vec_add(a,b)` `vec_sub(a,b)` `vec_mul(v, s)`
- `vec_dot(a,b)` `vec_len(v)` `vec_norm(v)` `vec_dist(a,b)`
- `vec_dim(v)` `vec_axis(v,i)` `vec_lerp(a,b,t)` `vec_limit(v,maxLen)`

## 8) clamp / lerp
```frinds
x = clamp(x, 0, 100)
y = lerp(0, 10, 0.5)
```

## 9) Libraries (sandbox)

โหลด module แบบ allowlist + cache:
```frinds
m = get("math")
-- หรือ
m = lib("math")
-- หรือ
import "math" as m
```

> หมายเหตุ: ทุก module ถูกควบคุมด้วย allowlist เพื่อความปลอดภัย

## 10) Project template (แนะนำ)
ดูโฟลเดอร์ `project_template/` สำหรับโครงสร้างที่รองรับการเพิ่ม library ในอนาคต
