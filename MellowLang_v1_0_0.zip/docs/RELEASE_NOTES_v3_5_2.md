# MellowLang v3.5.2

- เพิ่มรองรับไอคอนในขั้นตอน build exe (PyInstaller --icon)
- เพิ่ม VS Code Extension (Syntax + LSP: autocomplete/diagnostics)
- Installer สามารถติดตั้ง VS Code extension (.vsix) ให้อัตโนมัติเมื่อพบคำสั่ง code
- เพิ่มการติดตั้งไฟล์สำคัญ: examples/, docs/, project_template/ (เป็นตัวอย่าง)

