# MellowLang v1.0.0

MellowLang คือ Sandbox Scripting Engine (โฟกัส game/AI) รองรับไฟล์สคริปต์ `.mellow` (แนะนำ), `.fds` และ `.frinds` (legacy).

## Run (dev)
```bash
python -m mellowlang examples/v3_5_0_test_vector.frinds
```

## Install as CLI (pip editable)
```bash
pip install -e .
mellow examples/v3_5_0_test_vector.frinds
```

## Build Windows EXE (PyInstaller)
ดูไฟล์: `packaging/windows/build_exe.bat`

## Build Windows Installer (Inno Setup)
ดูไฟล์: `packaging/windows/mellowlang.iss`


## Build (Windows)
- Build EXE: `packaging\windows\build_exe.bat`
- Build VS Code extension (.vsix): `packaging\windows\build_vsix.bat`
- Build Installer: open `packaging\windows\mellowlang.iss` with Inno Setup and Compile

> Installer จะติดตั้ง VS Code extension ให้อัตโนมัติ ถ้ามีไฟล์ `vscode-extension\dist\mellowlang.vsix` และพบ `code.cmd` ในเครื่อง
