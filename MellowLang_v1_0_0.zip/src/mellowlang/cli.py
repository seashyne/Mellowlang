from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from mellowlang import __version__
from mellowlang.compiler import Compiler
from mellowlang.host import default_host
from mellowlang.replay import ReplayConfig
from mellowlang.vm import MellowLangVM


# ----------------------------
# Console helpers
# ----------------------------

def _supports_ansi() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.name != "nt":
        return True
    env = os.environ
    return any(k in env for k in ("WT_SESSION", "TERM", "ANSICON", "ConEmuANSI")) or (
        "vscode" in env.get("TERM_PROGRAM", "").lower()
    )


def _print_pretty_error(
    err: Exception,
    filename: str | None = None,
    source_lines: list[str] | None = None,
    *,
    use_color: bool | None = None,
) -> None:
    msg = str(err)
    if use_color is None:
        use_color = _supports_ansi()

    if use_color:
        RED = "\033[31m"
        YELLOW = "\033[33m"
        BLUE = "\033[34m"
        DIM = "\033[2m"
        BOLD = "\033[1m"
        RESET = "\033[0m"
    else:
        RED = YELLOW = BLUE = DIM = BOLD = RESET = ""

    print(f"{RED}error:{RESET} {msg}")

    trace = getattr(err, "trace", None)
    if trace:
        print(f"{BOLD}call stack:{RESET}")
        for fr in reversed(trace):
            nm = fr.get("name", "<frame>")
            fn = fr.get("filename", filename) or "<script>"
            ln = fr.get("line")
            col = fr.get("col")
            loc = fn if ln is None else f"{fn}:{ln}" + (f":{col}" if col else "")
            print(f"  {BLUE}at{RESET} {nm} ({loc})")

    if not filename or not source_lines:
        return

    # Best-effort caret location
    line_no = getattr(err, "line", None)
    col = getattr(err, "col", None)

    if not line_no:
        return

    line_no = int(line_no)
    col = int(col or 1)

    print(f"{DIM}--> {filename}:{line_no}:{col}{RESET}")
    lo = max(1, line_no - 1)
    hi = min(len(source_lines), line_no + 1)
    for ln in range(lo, hi + 1):
        src = source_lines[ln - 1].rstrip("\n")
        prefix = ">" if ln == line_no else " "
        pfx = f"{YELLOW}{prefix}{RESET}" if ln == line_no else prefix
        print(f"{pfx} {ln:4d} | {src}")
        if ln == line_no:
            caret_col = max(1, min(col, len(src) + 1))
            print("  " + " " * 4 + " | " + " " * (caret_col - 1) + f"{YELLOW}^{RESET}")


def _prog_name() -> str:
    base = os.path.basename(sys.argv[0]) or "mellow"
    return os.path.splitext(base)[0]


def _parse_json_args(raw: str | None) -> list[Any]:
    if not raw:
        return []
    try:
        data = json.loads(raw)
        return data if isinstance(data, list) else [data]
    except Exception:
        return []


# ----------------------------
# CLI
# ----------------------------

DEFAULT_EXTS = (".mellow", ".fds", ".frinds")  # .frinds kept for legacy compatibility


def build_parser() -> argparse.ArgumentParser:
    prog = _prog_name()
    desc = (
        f"MellowLang {__version__} — sandbox scripting engine (game/AI focused)\n"
        "Files: .mellow (recommended), .fds (events), .frinds (legacy)\n"
    )
    epilog = (
        "Examples:\n"
        f"  {prog} hello.mellow\n"
        f"  {prog} examples/v3_5_0_test_vector.frinds\n"
        f"  {prog} examples/event_tick.fds --emit tick --emit-args [0.16]\n"
        f"  {prog} main.mellow --record replay.jsonl --seed 123\n"
        f"  {prog} main.mellow --replay replay.jsonl\n"
    )

    p = argparse.ArgumentParser(
        prog=prog,
        description=desc,
        epilog=epilog,
        formatter_class=argparse.RawTextHelpFormatter,
    )

    p.add_argument("script", nargs="?", help="Path to script file.")
    p.add_argument("--lsp", action="store_true", help="Start language server (LSP) for editors.")
    p.add_argument("--emit", dest="emit_name", help="Emit an event after script run.")
    p.add_argument("--emit-args", dest="emit_args_raw", help="JSON array for event args, e.g. [0.16].")

    mx = p.add_mutually_exclusive_group()
    mx.add_argument("--record", dest="record_path", help="Record deterministic replay log to a .jsonl file.")
    mx.add_argument("--replay", dest="replay_path", help="Replay from deterministic log (.jsonl).")

    p.add_argument("--seed", type=int, help="Per-script seed for deterministic random.")
    p.add_argument("--global-seed", type=int, help="Global base seed for deterministic runs across scripts.")

    p.add_argument("--color", action="store_true", help="Force colored error output (ANSI).")
    p.add_argument("--no-color", action="store_true", help="Disable colored error output.")

    p.add_argument("--version", action="version", version=f"{prog} {__version__}", help="Show version and exit.")

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.lsp:
        from mellowlang.lsp_server import start_lsp
        return int(start_lsp() or 0)

    if not args.script:
        build_parser().print_help()
        return 2

    path = Path(args.script)
    if not path.exists():
        print(f"error: file not found: {path}")
        return 1

    if path.suffix.lower() not in DEFAULT_EXTS:
        print(f"warning: unknown extension '{path.suffix}'. Recommended: .mellow")

    lines = path.read_text(encoding="utf-8").splitlines(True)

    try:
        comp = Compiler()
        bytecode = comp.compile(lines)
        host = default_host()

        if args.record_path:
            replay_cfg = ReplayConfig(mode="record", path=args.record_path)
        elif args.replay_path:
            replay_cfg = ReplayConfig(mode="replay", path=args.replay_path)
        else:
            replay_cfg = ReplayConfig(mode="off", path=None)

        config: dict[str, Any] = {
            "allow_ask": False,
            "allow_storage": True,
            "allow_wait": True,
            "max_steps": 250_000,
            "syscall_budget": 800,
        }
        if args.seed is not None:
            config["seed"] = int(args.seed)
        if args.global_seed is not None:
            config["global_seed"] = int(args.global_seed)

        vm = MellowLangVM(
            bytecode,
            comp.functions,
            comp.events,
            config=config,
            host=host,
            replay=replay_cfg,
            filename=str(path),
            source_lines=lines,
            line_map=comp.line_map,
            col_map=getattr(comp, "col_map", None),
        )
        vm.run()

        if args.emit_name:
            emit_args = _parse_json_args(args.emit_args_raw)
            vm.emit(args.emit_name, emit_args)

        return 0

    except Exception as e:
        _print_pretty_error(
            e,
            filename=str(path),
            source_lines=lines,
            use_color=(True if args.color else (False if args.no_color else None)),
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
