# frinds/storage_core.py
import json
import os

class StorageCore:
    """Sandboxed JSON persistence.

    - Saves only under a dedicated directory (default: ./frinds_saves)
    - Prevents path traversal
    - Forces .json extension
    """
    def __init__(self, engine, base_dir="frinds_saves"):
        self.engine = engine
        self.commands = ["save_data", "load_data"]
        self.base_dir = base_dir
        
    def _safe_path(self, filename: str) -> str:
        # Accept "save.json" or "save" (auto add .json)
        if not isinstance(filename, str):
            filename = str(filename)
        name = os.path.basename(filename.strip().strip('"').strip("'"))
        if not name:
            return os.path.join(self.base_dir, "save.json")
        if not name.lower().endswith(".json"):
            name += ".json"
        return os.path.join(self.base_dir, name)

    def execute(self, name, args):
        if name == "save_data":
            return self.save_data(args[0] if len(args) > 0 else None,
                                  args[1] if len(args) > 1 else "save.json")
        if name == "load_data":
            return self.load_data(args[0] if args else "save.json")
        return None

    def save_data(self, data, filename):
        try:
            path = self._safe_path(filename)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            return True
        except Exception as e:
            if hasattr(self.engine, 'error_handler'):
                self.engine.error_handler.report("STORAGE", str(e))
            return False

    def load_data(self, filename):
        try:
            path = self._safe_path(filename)
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return None
        except Exception as e:
            if hasattr(self.engine, 'error_handler'):
                self.engine.error_handler.report("STORAGE", str(e))
            return None
