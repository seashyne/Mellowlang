"""frinds/lint.py (v3.4.0)

Simple linter/formatter for MellowLang.

Goals (sandbox-friendly):
- Catch syntax errors via parser
- Provide a basic formatter (tabs -> 4 spaces, trim trailing spaces, normalize blank lines)

This is intentionally lightweight (no heavy AST rewriter yet).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from .parser import parse_program, ParseError


@dataclass
class LintIssue:
    kind: str  # SYNTAX / STYLE
    message: str
    line: Optional[int] = None


def lint_source(src: str) -> List[LintIssue]:
    """Return issues (never raises)."""
    issues: List[LintIssue] = []
    lines = src.splitlines()
    try:
        parse_program(lines)
    except ParseError as e:
        issues.append(LintIssue("SYNTAX", str(e)))
        return issues

    # very small style checks
    for i, ln in enumerate(lines, start=1):
        if "\t" in ln:
            issues.append(LintIssue("STYLE", "tab character found; use spaces", i))
        if ln.rstrip("\n") != ln.rstrip("\n").rstrip(" "):
            issues.append(LintIssue("STYLE", "trailing spaces", i))
    return issues


def format_source(src: str) -> str:
    """Best-effort formatter.

    - Converts tabs to 4 spaces
    - Strips trailing spaces
    - Collapses 3+ blank lines into 2
    """
    out_lines: List[str] = []
    blank_run = 0
    for ln in src.splitlines():
        ln = ln.replace("\t", "    ").rstrip()
        if ln.strip() == "":
            blank_run += 1
            if blank_run <= 2:
                out_lines.append("")
            continue
        blank_run = 0
        out_lines.append(ln)
    return "\n".join(out_lines) + ("\n" if src.endswith("\n") else "")


def _main(argv: List[str]) -> int:
    import argparse
    import sys

    p = argparse.ArgumentParser(prog="frinds-lint")
    p.add_argument("file", help=".frinds script file")
    p.add_argument("--format", action="store_true", help="rewrite file in-place")
    args = p.parse_args(argv)

    with open(args.file, "r", encoding="utf-8") as f:
        src = f.read()

    if args.format:
        formatted = format_source(src)
        with open(args.file, "w", encoding="utf-8") as f:
            f.write(formatted)
        src = formatted

    issues = lint_source(src)
    if not issues:
        print("OK")
        return 0
    for it in issues:
        loc = f"line {it.line}: " if it.line else ""
        print(f"{it.kind}: {loc}{it.message}")
    return 1


if __name__ == "__main__":
    import sys
    raise SystemExit(_main(sys.argv[1:]))
