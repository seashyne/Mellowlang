import os
import sys
from pathlib import Path

def _add_paths() -> None:
    # When running from a PyInstaller onefile exe
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass and meipass not in sys.path:
            sys.path.insert(0, meipass)
        return

    # Dev mode: import from repo ./src
    repo_root = Path(__file__).resolve().parents[2]
    src_path = str(repo_root / "src")
    if src_path not in sys.path:
        sys.path.insert(0, src_path)

_add_paths()

from mellowlang.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
