# frinds/list_core.py

class ListCore:
    def __init__(self, engine, max_list_len=10_000):
        self.engine = engine
        self.max_list_len = max_list_len

    def create_list(self, elements_str):
        elements = elements_str.strip("[]").strip()
        if not elements:
            return []
        parts = elements.split(",")
        out = [self.engine.evaluator.evaluate(e.strip()) for e in parts if e.strip()]
        if len(out) > self.max_list_len:
            if hasattr(self.engine, 'error_handler'):
                self.engine.error_handler.report("LIST", f"List too large (>{self.max_list_len})")
            return out[:self.max_list_len]
        return out

    def handle_command(self, line):
        # put "sword" into inventory
        if line.startswith("put ") and " into " in line:
            parts = line.split(" into ", 1)
            item = self.engine.evaluator.evaluate(parts[0][4:])
            list_name = parts[1].strip()
            if list_name in self.engine.variables and isinstance(self.engine.variables[list_name], list):
                if len(self.engine.variables[list_name]) >= self.max_list_len:
                    if hasattr(self.engine, 'error_handler'):
                        self.engine.error_handler.report("LIST", f"'{list_name}' is full")
                else:
                    self.engine.variables[list_name].append(item)
            else:
                if hasattr(self.engine, 'error_handler'):
                    self.engine.error_handler.report("VARIABLE", list_name)
