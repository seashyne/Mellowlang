# frinds/core.py
import re

from mellowlang.time_core import TimeCore
from mellowlang.evaluator import Evaluator
from mellowlang.math_core import MathCore
from mellowlang.error_core import MellowLangError
from mellowlang.list_core import ListCore
from mellowlang.storage_core import StorageCore

DEFAULT_CONFIG = {
    # Sandbox switches
    "allow_ask": False,
    "allow_wait": True,
    "allow_storage": True,

    # Safety limits
    "max_steps": 200_000,
    "max_loop_iterations": 50_000,
    "max_recursion": 50,
}

class MellowLangEngine:
    """Interpreter (direct execution) with sandbox limits.

    For stronger sandbox, prefer Compiler -> VM (bytecode) execution.
    """
    def __init__(self, parent=None, config=None):
        self.parent = parent
        self.variables = parent.variables if parent else {}
        self.functions = parent.functions if parent else {}
        self.precision = parent.precision if parent else None

        self.config = dict(DEFAULT_CONFIG)
        if parent and hasattr(parent, 'config'):
            self.config.update(parent.config)
        if config:
            self.config.update(config)

        self.current_line = 0
        self.is_stopped = False
        self._steps = 0
        self._rec_depth = (getattr(parent, '_rec_depth', 0) if parent else 0)

        self.evaluator = Evaluator(self)
        self.math_core = MathCore(self)
        self.time_core = parent.time_core if parent else TimeCore()

        self.error_handler = MellowLangError(self)
        self.list_core = ListCore(self)

        # Storage sandbox
        self.storage_core = parent.storage_core if parent else StorageCore(self)

    def _tick(self):
        self._steps += 1
        if self._steps > int(self.config.get('max_steps', 200_000)):
            self.error_handler.report("SANDBOX", "Step limit exceeded")
            self.is_stopped = True

    def call_skill(self, name, args):
        if self._rec_depth >= int(self.config.get('max_recursion', 50)):
            self.error_handler.report("SANDBOX", "Max recursion depth exceeded")
            return None
        func_data = self.functions[name]
        sub = MellowLangEngine(parent=self, config=self.config)
        sub._rec_depth = self._rec_depth + 1
        for i, p_name in enumerate(func_data["params"]):
            if i < len(args):
                sub.variables[p_name] = args[i]
        return sub.run(func_data["body"])

    def get_block(self, lines):
        block = []
        while self.current_line + 1 < len(lines):
            nxt = lines[self.current_line + 1]
            if not nxt.strip():
                self.current_line += 1
                continue
            if nxt.startswith("    ") or nxt.startswith("\t"):
                block.append(nxt)
                self.current_line += 1
            else:
                break
        return block

    def format_value(self, val):
        if isinstance(val, (float, int)):
            if self.precision is not None:
                return f"{float(val):.{int(self.precision)}f}"
            if isinstance(val, float) and val.is_integer():
                return int(val)
        return val

    def run_sub_block(self, lines):
        cleaned = [l[4:] if l.startswith("    ") else l[1:] if l.startswith("\t") else l for l in lines]
        sub = MellowLangEngine(parent=self, config=self.config)
        res = sub.run(cleaned)
        if res == "STOP_SIGNAL":
            return "STOP_SIGNAL"
        return res

    def evaluate_boolean(self, cond):
        clean = str(cond).replace("true", "True").replace("false", "False").strip()
        if clean == "True": return True
        if clean == "False": return False

        # Special: list has item
        if " has " in clean:
            parts = clean.split(" has ", 1)
            var_val = self.evaluator.evaluate(parts[0].strip())
            item_val = self.evaluator.evaluate(parts[1].strip())
            return isinstance(var_val, list) and item_val in var_val

        for op in ['==', '!=', '>=', '<=', '>', '<']:
            if op in clean:
                l, r = clean.split(op, 1)
                vl = self.evaluator.evaluate(l)
                vr = self.evaluator.evaluate(r)
                try:
                    v1, v2 = float(vl), float(vr)
                    if op == '==': return v1 == v2
                    if op == '!=': return v1 != v2
                    if op == '>':  return v1 > v2
                    if op == '<':  return v1 < v2
                    if op == '>=': return v1 >= v2
                    if op == '<=': return v1 <= v2
                except:
                    if op == '==': return str(vl) == str(vr)
                    if op == '!=': return str(vl) != str(vr)
        return False

    def run(self, lines):
        self.current_line = 0
        last_group_executed = False

        while self.current_line < len(lines):
            if self.is_stopped:
                break
            self._tick()

            line = lines[self.current_line].strip()
            if not line or line.startswith("//"):
                self.current_line += 1
                continue

            # keep x = expr
            if line.startswith("keep "):
                m = re.match(r"keep\s+(\w+)\s*=\s*(.*)", line)
                if not m:
                    self.error_handler.report("SYNTAX", line)
                    self.current_line += 1
                    continue
                var_name, expr = m.groups()
                expr = expr.strip()
                if expr.startswith("[") and expr.endswith("]"):
                    self.variables[var_name] = self.list_core.create_list(expr)
                else:
                    self.variables[var_name] = self.evaluator.evaluate(expr)
                last_group_executed = False

            elif line.startswith("put "):
                self.list_core.handle_command(line)
                last_group_executed = False

            elif line.startswith("precision("):
                m = re.search(r'precision\((.*)\)', line)
                if m:
                    self.precision = int(self.evaluator.evaluate(m.group(1)))
                last_group_executed = False

            elif line.startswith("show("):
                m = re.search(r'show\((.*)\)', line)
                if m:
                    print(self.format_value(self.evaluator.evaluate(m.group(1))))
                last_group_executed = False

            elif line == "stop":
                self.is_stopped = True
                return "STOP_SIGNAL"

            elif line.startswith("check "):
                m = re.search(r'\((.*)\)', line)
                cond = m.group(1) if m else "False"
                sub_lines = self.get_block(lines)
                if self.evaluate_boolean(cond):
                    if self.run_sub_block(sub_lines) == "STOP_SIGNAL":
                        return "STOP_SIGNAL"
                    last_group_executed = True
                else:
                    last_group_executed = False

            elif line.startswith("also"):
                m = re.search(r'\((.*)\)', line)
                cond = m.group(1) if m else "False"
                sub_lines = self.get_block(lines)
                if not last_group_executed and self.evaluate_boolean(cond):
                    if self.run_sub_block(sub_lines) == "STOP_SIGNAL":
                        return "STOP_SIGNAL"
                    last_group_executed = True

            elif line.startswith("else:"):
                sub_lines = self.get_block(lines)
                if not last_group_executed:
                    if self.run_sub_block(sub_lines) == "STOP_SIGNAL":
                        return "STOP_SIGNAL"
                last_group_executed = True

            elif line.startswith("loop"):
                m = re.search(r'\((.*)\)', line)
                cond_str = m.group(1) if m else "True"
                sub_lines = self.get_block(lines)
                it = 0
                while self.evaluate_boolean(cond_str):
                    self._tick()
                    it += 1
                    if it > int(self.config.get('max_loop_iterations', 50_000)):
                        self.error_handler.report("SANDBOX", "Loop iteration limit exceeded")
                        break
                    if self.run_sub_block(sub_lines) == "STOP_SIGNAL":
                        break
                last_group_executed = False

            elif line.startswith("skill "):
                m = re.match(r"skill\s+(\w+)\((.*)\):", line)
                if m:
                    name, p = m.groups()
                    params = [x.strip() for x in p.split(',') if x.strip()]
                    self.functions[name] = {"params": params, "body": self.get_block(lines)}
                last_group_executed = False

            elif line.startswith("wait("):
                if not self.config.get('allow_wait', True):
                    self.error_handler.report("SANDBOX", "wait() is disabled")
                else:
                    m = re.search(r'wait\((.*)\)', line)
                    if m:
                        seconds = self.evaluator.evaluate(m.group(1))
                        self.time_core.wait(seconds)
                last_group_executed = False

            elif line.startswith("save ") and " into " in line:
                if not self.config.get('allow_storage', True):
                    self.error_handler.report("SANDBOX", "save/load is disabled")
                else:
                    parts = line[5:].split(" into ", 1)
                    data = self.evaluator.evaluate(parts[0].strip())
                    filename = self.evaluator.evaluate(parts[1].strip())
                    self.storage_core.execute("save_data", [data, filename])
                last_group_executed = False

            elif line.startswith("load ") and " into " in line:
                if not self.config.get('allow_storage', True):
                    self.error_handler.report("SANDBOX", "save/load is disabled")
                else:
                    parts = line[5:].split(" into ", 1)
                    filename = self.evaluator.evaluate(parts[0].strip())
                    var_name = parts[1].strip()
                    data = self.storage_core.execute("load_data", [filename])
                    self.variables[var_name] = data
                last_group_executed = False

            else:
                self.error_handler.report("SYNTAX", line)

            self.current_line += 1

        return None
