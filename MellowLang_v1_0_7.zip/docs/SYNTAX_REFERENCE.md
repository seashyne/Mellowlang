# MellowLang Syntax Reference (v1.0.3)



## Recommended Modern Syntax (v1.0.3)

MellowLang supports several aliases for friendliness, but for tutorials and team codebases we recommend:

- Use **`print(...)`** instead of `show(...)`
- Use **`input(...)`** instead of `ask(...)` (note: may require `--allow-ask`)
- Prefer **Python-like `for` / `while`** loop styles when possible

Older/alternative forms remain supported for compatibility.

---

ดูไฟล์ `MELLOWLANG_User_Manual.md` สำหรับคู่มือเต็ม


## Modern Recommended Syntax (v1.0.7)

MellowLang keeps legacy keywords for compatibility, but **new projects should prefer these modern forms**:

- Variables: `let name = expr` (alias of `keep`)  
  Also allowed: `var name = expr`, `keep name = expr`
- Print: `print(expr)` (alias of `show(expr)`)
- Input: `input("prompt")` (alias of `ask("prompt")`)
- Functions: `def add(a,b):` (alias of `skill add(a,b):`)
- Blocks: **indentation-based** (no `end`)
- Loops: prefer `for i in range(0, n):` and `while cond:` (Python-like)

> Tip: You can still mix Lua-like and legacy forms, but the above is the "clean" style used in official examples.
