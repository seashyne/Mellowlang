from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Any

from .legacy import Compiler as _LegacyCompiler  # legacy implementation (bytecode compiler)

@dataclass(frozen=True)
class CompiledProgram:
    """A compiled MellowLang program.

    Stable API between CLI ↔ Compiler ↔ VM (v1.0.3+).
    """
    bytecode: List[tuple]
    func_table: dict | None = None
    event_table: dict | None = None
    filename: Optional[str] = None
    source_lines: Optional[List[str]] = None
    line_map: Optional[List[int]] = None
    col_map: Optional[List[int]] = None

class Compiler:
    """Stable compiler facade.

    Contract:
      - compile(source, filename=None) -> CompiledProgram
    """

    def __init__(self) -> None:
        self._impl = _LegacyCompiler()

    def compile(self, source: str, *, filename: str | None = None) -> CompiledProgram:
        # legacy compiler expects list[str] (lines without trailing newlines are ok)
        from ..error_core import MellowLangRuntimeError
        lines = source.splitlines()
        try:
            bytecode = self._impl.compile(lines, filename=filename)
        except MellowLangRuntimeError:
            raise
        except Exception as e:
            raise MellowLangRuntimeError('COMPILER', str(e), None, filename=filename)
        return CompiledProgram(
            bytecode=bytecode,
            func_table=getattr(self._impl, "functions", None),
            event_table=getattr(self._impl, "events", None),
            filename=filename,
            source_lines=source.splitlines(),
            line_map=getattr(self._impl, 'line_map', None),
            col_map=getattr(self._impl, 'col_map', None),
        )
