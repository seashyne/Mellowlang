from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Any, Dict

from ..replay import ReplayConfig
from ..host import HostRegistry, default_host
from .legacy import MellowLangVM as _LegacyVM
from ..compiler import Compiler as _LegacyCompiler
from ..compiler.compiler import CompiledProgram

@dataclass(frozen=True)
class RunConfig:
    seed: Optional[int] = None
    global_seed: Optional[int] = None
    record_path: Optional[str] = None
    replay_path: Optional[str] = None
    allow_ask: bool = False
    allow_wait: bool = True

class MellowVM:
    """Stable VM facade.

    Contract:
      - run(program, config=RunConfig(...), host=None) -> Any
    """
    def __init__(self, *, host: HostRegistry | None = None) -> None:
        self._host = host or default_host()

    def run(self, program: CompiledProgram, *, config: RunConfig | None = None) -> Any:
        cfg = config or RunConfig()
        config_dict: Dict[str, Any] = {
            "allow_ask": bool(cfg.allow_ask),
            "allow_wait": bool(cfg.allow_wait),
        }
        if cfg.seed is not None:
            config_dict["seed"] = int(cfg.seed)
        if cfg.global_seed is not None:
            config_dict["global_seed"] = int(cfg.global_seed)

        replay = None
        if cfg.record_path:
            replay = ReplayConfig(mode="record", path=str(cfg.record_path))
        elif cfg.replay_path:
            replay = ReplayConfig(mode="replay", path=str(cfg.replay_path))

        # legacy VM expects bytecode at construction time
        vm = _LegacyVM(
            program.bytecode,
            func_table=getattr(program, "func_table", None),
            event_table=getattr(program, "event_table", None),
            host=self._host,
            config=config_dict,
            replay=replay,
            filename=program.filename,
            source_lines=program.source_lines,
            line_map=getattr(program, 'line_map', None),
            col_map=getattr(program, 'col_map', None),
        )
        return vm.run()
