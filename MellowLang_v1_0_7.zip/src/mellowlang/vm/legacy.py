
# frinds/vm.py (v2.2)
from __future__ import annotations
from typing import Any, List
from ..constants import Op
from ..host import HostRegistry, default_host
from ..replay import ReplayConfig, ReplayLog
from ..error_core import MellowLangRuntimeError
from ..range_core import MellowLangRange

class MellowLangVM:
    def __init__(self, bytecode, func_table=None, event_table=None, *, config=None, host: HostRegistry | None = None, replay: ReplayConfig | None = None, filename: str | None = None, source_lines: list[str] | None = None, line_map: list[int] | None = None, col_map: list[int] | None = None):
        self.bytecode = bytecode or []
        self.func_table = func_table or {}
        self.event_table = event_table or {}  # event_name -> meta

        self.stack: List[Any] = []
        self.call_stack: List[int] = []
        self.frame_stack: List[dict] = []  # function/event frames for trace
        self.variables = [{}]  # scope stack (0 = global)

        self.pc = 0
        self.precision = None

        # Debug info for pretty errors
        self.filename = filename
        self.source_lines = source_lines or []
        self._line_map = line_map or []
        self._col_map = col_map or []
        self._try_stack: list[dict] = []  # stack of try frames

        self.config = {
            # Permissions
            "allow_ask": False,
            "allow_wait": True,
            "allow_storage": True,

            # Limits
            "max_steps": 200_000,
            "max_stack": 2_000,
            "max_string_len": 20_000,
            "max_list_len": 5_000,
            "max_map_keys": 2_000,

            # Budget for syscalls (anti-spam)
            "syscall_budget": 500,
        }
        if config:
            self.config.update(config)

        self.host = host or default_host()
        self._steps = 0
        self._budget = int(self.config.get("syscall_budget", 500))

        # Deterministic RNG + Replay
        import random as _random
        import hashlib as _hashlib

        self._replay = ReplayLog(replay or ReplayConfig())

        # Global base seed (optional): used to derive per-script seeds deterministically.
        # This keeps MellowLang identity: deterministic-by-default + sandboxed (no external entropy).
        self._global_seed = None
        if "global_seed" in self.config:
            try:
                self._global_seed = int(self.config.get("global_seed"))
            except Exception:
                self._global_seed = None
        else:
            # NOTE(v3.6.1): do not load global seed from disk implicitly
            self._global_seed = None

        def _derive_seed(base: int, name: str) -> int:
            payload = f"{int(base)}::{name}".encode("utf-8")
            digest = _hashlib.sha256(payload).digest()
            return int.from_bytes(digest[:8], "little", signed=False)

        if (replay or ReplayConfig()).mode == "replay":
            seed = int(self._replay.next_seed())
        else:
            if self._global_seed is not None:
                seed = _derive_seed(int(self._global_seed), str(self.filename or "<memory>"))
            else:
                seed = int(self.config.get("seed", 12345))
            self._replay.record_seed(seed)

        self.rng = _random.Random(seed)

        # ---------------- Persistent keep store ----------------
        # keep vars survive across runs by default (can be disabled via config)
        self._keep_dirty = False
        self._keep_enabled = bool(self.config.get("allow_storage", True)) and bool(self.config.get("keep_persistent", True))
        self._keep_values: dict[str, Any] = {}
        if self._keep_enabled:
            try:
                # isolate by filename (script) to avoid collisions
                key = (self.filename or "<memory>")
                data = self._load_json(f"__keep__{key}")
                if isinstance(data, dict):
                    self._keep_values = data
            except Exception:
                # keep is best-effort; never break sandbox on load
                self._keep_values = {}

    # ---------------- Sandbox helpers ----------------
    def _tick(self):
        self._steps += 1
        if self._steps > int(self.config.get("max_steps", 200_000)):
            self._raise_sandbox("Step limit exceeded")
        if len(self.stack) > int(self.config.get("max_stack", 2_000)):
            self._raise_sandbox("Stack limit exceeded")

    def _enforce_value_limits(self, v):
        ms = int(self.config.get("max_string_len", 20_000))
        ml = int(self.config.get("max_list_len", 5_000))
        mk = int(self.config.get("max_map_keys", 2_000))
        if isinstance(v, str) and len(v) > ms:
            self._raise_sandbox("String too large")
        if isinstance(v, list) and len(v) > ml:
            self._raise_sandbox("List too large")
        if isinstance(v, dict) and len(v) > mk:
            self._raise_sandbox("Map too large")

    # ---------------- Utilities ----------------
    def format_value(self, val):
        if isinstance(val, (float, int)):
            if self.precision is not None:
                try:
                    return f"{float(val):.{int(self.precision)}f}"
                except:
                    pass
            if isinstance(val, float) and val.is_integer():
                return str(int(val))
            return str(val)
        return str(val)

    def _load_var(self, name):
        for scope in reversed(self.variables):
            if name in scope:
                return scope[name]
        if self._keep_enabled and name in self._keep_values:
            return self._keep_values.get(name)
        return 0

    def _truthy(self, v) -> bool:
        return bool(v)

    # ---------------- Syscall ----------------
    def _syscall(self, name: str, args: list):
        if not isinstance(name, str):
            self._raise_sandbox("syscall name must be string")
        if not self.host.has(name):
            self._raise_sandbox(f"syscall not allowed: {name}")

        cost = int(self.host.get_cost(name))
        self._budget -= cost
        if self._budget < 0:
            self._raise_sandbox("syscall budget exceeded")

        # Replay mode: return recorded result without calling host
        if self._replay.cfg.mode == "replay":
            res = self._replay.next_syscall_result(name, args)
            self._enforce_value_limits(res)
            return res

        res = self.host.call(name, args)
        self._enforce_value_limits(res)
        self._replay.record_syscall(name, args, res)
        return res

    # ---------------- Storage helpers ----------------
    def _safe_path(self, filename: Any) -> str:
        import os
        base_dir = self.config.get("storage_dir", "mellow_saves")
        raw = str(filename).strip().strip('"').strip("'")
        raw = raw.replace('\\', '/').lstrip('/')
        if not raw or raw in ('.', '..'):
            raw = 'save.json'

        # Force .json extension for storage save/load
        if not raw.lower().endswith('.json'):
            raw = raw + '.json'

        # Join under base_dir and prevent traversal / absolute paths
        base_norm = os.path.normpath(base_dir)
        path = os.path.normpath(os.path.join(base_norm, raw))
        if not (path == base_norm or path.startswith(base_norm + os.sep)):
            self._raise_sandbox("invalid storage path (path traversal blocked)")
        return path

    def _save_json(self, filename: Any, value: Any):
        if not self.config.get("allow_storage", True):
            self._raise_sandbox("storage is disabled")
        import json, os, tempfile
        path = self._safe_path(filename)

        # Base storage directory is NOT auto-created.
        base_dir = self.config.get("storage_dir", "mellow_saves")
        if not os.path.isdir(base_dir):
            self._raise_runtime(f"Storage base folder '{base_dir}' does not exist (create it first)")

        # If user asked for subfolder, they must create it themselves.
        dirpath = os.path.dirname(path) or base_dir
        if os.path.normpath(dirpath) != os.path.normpath(base_dir) and not os.path.exists(dirpath):
            self._raise_runtime(f"Folder not found: {dirpath} (create it first)")

        # Atomic write: write temp then replace
        fd, tmp = tempfile.mkstemp(prefix=".mellow_", suffix=".tmp", dir=dirpath)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(value, f, ensure_ascii=False)
            os.replace(tmp, path)
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

    def _load_json(self, filename: Any):
        if not self.config.get("allow_storage", True):
            self._raise_sandbox("storage is disabled")
        import json, os
        path = self._safe_path(filename)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    
    # ---------------- Events ----------------
    def emit(self, event_name: str, args: list | None = None):
        """Trigger an event handler registered via on("event"):. Returns handler return value."""
        args = args or []
        if event_name not in self.event_table:
            return None
        meta = self.event_table[event_name]
        self._replay.record_emit(event_name, args)

        # Push args in order (will be popped by ARG in reverse)
        for a in args:
            self.stack.append(a)

        pcount = int(meta.get("param_count", 0))
        argc = len(args)
        if argc > pcount:
            self._raise_sandbox(f"too many args for event {event_name} (got {argc}, want {pcount})")
        for _ in range(pcount - argc):
            self.stack.append(None)

        # Call like a function
        return_pc = self.pc
        self.call_stack.append(return_pc)
        self.frame_stack.append({"name": f"event:{event_name}", "filename": self.filename, "line": None, "col": None})
        self.variables.append({})
        self.pc = int(meta["address"])
        self.run()
        # After RETURN, result will be on stack
        return self.stack.pop() if self.stack else None

# ---------------- Run ----------------

    def _pos(self):
        """Return (line, col) for current pc if available."""
        line = None
        col = None
        if self._line_map and 0 <= self.pc < len(self._line_map):
            ln = int(self._line_map[self.pc] or 0)
            line = ln if ln > 0 else None
        if self._col_map and 0 <= self.pc < len(self._col_map):
            c = int(self._col_map[self.pc] or 1)
            col = c if c > 0 else 1
        return line, col

    
    def _build_trace(self, line: int | None, col: int | None):
        trace = []
        # frame_stack contains call frames (function/event)
        for fr in self.frame_stack:
            trace.append(dict(fr))
        # add current context frame
        cur_name = trace[-1]["name"] if trace else "<main>"
        trace.append({
            "name": cur_name,
            "filename": self.filename,
            "line": line,
            "col": col,
        })
        return trace

    def _raise_runtime(self, message: str):
        line, col = self._pos()
        raise MellowLangRuntimeError('RUNTIME', message, line, filename=self.filename, col=col, trace=self._build_trace(line, col))

    def _raise_sandbox(self, message: str):
        line, col = self._pos()
        raise MellowLangRuntimeError('SANDBOX', message, line, filename=self.filename, col=col, trace=self._build_trace(line, col))



    def _handle_exception(self, e: Exception):
        # if inside try: jump to catch/finally
        if self._try_stack:
            frame = self._try_stack.pop()
            # restore stack length
            self.stack = self.stack[:frame.get('stack_len', len(self.stack))]
            # bind error name if provided
            err_name = frame.get('err_name')
            if err_name:
                self.variables[-1][err_name] = str(e)
            # jump to catch_pc (or finally_pc)
            self.pc = int(frame.get('catch_pc', self.pc))
            return True
        # otherwise raise pretty runtime error
        self._raise_runtime(str(e))
        return False
    def run(self):
        while self.pc < len(self.bytecode):
            self._tick()
            instr = self.bytecode[self.pc]
            op = instr[0]
            try:
                if op in (Op.HALT, Op.STOP):
                    break

                elif op == Op.TRY:
                    catch_pc = int(instr[1])
                    finally_pc = int(instr[2])
                    err_name = instr[3] if len(instr) > 3 else None
                    self._try_stack.append({
                        'catch_pc': catch_pc,
                        'finally_pc': finally_pc,
                        'err_name': err_name,
                        'stack_len': len(self.stack),
                    })

                elif op == Op.ENDTRY:
                    if self._try_stack:
                        self._try_stack.pop()

                elif op == Op.PUSH:
                    val = instr[1]
                    # Normalize simple literals
                    if isinstance(val, str):
                        low = val.lower()
                        if low == 'true': val = True
                        elif low == 'false': val = False
                        elif low in ('none', 'null'): val = None
                        else:
                            s = val
                            if s.replace('.', '', 1).replace('-', '', 1).isdigit():
                                val = float(s) if '.' in s else int(s)
                    self._enforce_value_limits(val)
                    self.stack.append(val)

                elif op == Op.STORE:
                    self.variables[-1][instr[1]] = self.stack.pop() if self.stack else None

                elif op == Op.STORE_AUTO:
                    name = instr[1]
                    val = self.stack.pop() if self.stack else None
                    self.variables[-1][name] = val
                    # If the name exists in keep store, keep it in sync (ergonomic updates)
                    if self._keep_enabled and name in self._keep_values:
                        self._keep_values[name] = val
                        self._keep_dirty = True

                elif op == Op.STORE_KEEP:
                    name = instr[1]
                    val = self.stack.pop() if self.stack else None
                    # always store in current scope too (ergonomic)
                    self.variables[-1][name] = val
                    if self._keep_enabled:
                        self._keep_values[name] = val
                        self._keep_dirty = True

                elif op == Op.SEED:
                    # seed deterministic RNG
                    seed_val = self.stack.pop() if self.stack else 0
                    try:
                        seed_int = int(seed_val)
                    except Exception:
                        seed_int = 0
                    if self._replay.cfg.mode == "replay":
                        seed_int = int(self._replay.next_seed())
                    else:
                        self._replay.record_seed(seed_int)
                    import random as _random
                    self.rng = _random.Random(seed_int)

                elif op == Op.GLOBAL_SEED:
                    # global_seed(n): set global base seed, persist (best-effort),
                    # then derive and reseed current script RNG.
                    seed_val = self.stack.pop() if self.stack else 0
                    try:
                        base = int(seed_val)
                    except Exception:
                        base = 0

                    # NOTE(v3.6.1): do not persist global seed to disk implicitly

                    self._global_seed = base

                    # Derive deterministic per-script seed
                    try:
                        import hashlib as _hashlib
                        payload = f"{int(base)}::{str(self.filename or '<memory>')}".encode("utf-8")
                        digest = _hashlib.sha256(payload).digest()
                        seed_int = int.from_bytes(digest[:8], "little", signed=False)
                    except Exception:
                        seed_int = int(base)

                    if self._replay.cfg.mode == "replay":
                        seed_int = int(self._replay.next_seed())
                    else:
                        self._replay.record_seed(seed_int)

                    import random as _random
                    self.rng = _random.Random(seed_int)

                elif op == Op.LOAD:
                    self.stack.append(self._load_var(instr[1]))

                elif op == Op.ADD:
                    b = self.stack.pop(); a = self.stack.pop()
                    if isinstance(a, str) or isinstance(b, str):
                        out = self.format_value(a) + self.format_value(b)
                        self._enforce_value_limits(out)
                        self.stack.append(out)
                    else:
                        self.stack.append(a + b)

                elif op == Op.SUB:
                    b = self.stack.pop(); a = self.stack.pop()
                    self.stack.append(a - b)

                elif op == Op.MUL:
                    b = self.stack.pop(); a = self.stack.pop()
                    self.stack.append(a * b)

                elif op == Op.DIV:
                    b = self.stack.pop(); a = self.stack.pop()
                    # raise on division by zero (catchable by try/catch)
                    if b == 0:
                        raise ZeroDivisionError('division by zero')
                    self.stack.append(a / b)

                elif op == Op.PRINT:
                    print(self.format_value(self.stack.pop() if self.stack else None))

                elif op == Op.SHOW_PREC:
                    self.precision = self.stack.pop()

                elif op == Op.COMPARE:
                    cmp_op = instr[1] if len(instr) > 1 else '=='
                    b = self.stack.pop(); a = self.stack.pop()
                    num_ok = True
                    try:
                        af = float(a); bf = float(b)
                    except:
                        num_ok = False
                    if num_ok:
                        if cmp_op == '==': res = (af == bf)
                        elif cmp_op == '!=': res = (af != bf)
                        elif cmp_op == '>': res = (af > bf)
                        elif cmp_op == '<': res = (af < bf)
                        elif cmp_op == '>=': res = (af >= bf)
                        elif cmp_op == '<=': res = (af <= bf)
                        else: res = False
                    else:
                        if cmp_op == '==': res = (a == b)
                        elif cmp_op == '!=': res = (a != b)
                        else: res = False
                    self.stack.append(res)

                elif op == Op.BOOL_AND:
                    b = self.stack.pop(); a = self.stack.pop()
                    self.stack.append(self._truthy(a) and self._truthy(b))

                elif op == Op.BOOL_OR:
                    b = self.stack.pop(); a = self.stack.pop()
                    self.stack.append(self._truthy(a) or self._truthy(b))

                elif op == Op.BOOL_NOT:
                    a = self.stack.pop()
                    self.stack.append(not self._truthy(a))

                elif op == Op.LEN:
                    a = self.stack.pop()
                    try:
                        if isinstance(a, (list, dict, str, MellowLangRange)):
                            self.stack.append(len(a))
                        elif hasattr(a, "__len__") and hasattr(a, "__getitem__"):
                            # allow safe view-like iterables
                            self.stack.append(int(len(a)))
                        else:
                            self.stack.append(0)
                    except Exception:
                        self.stack.append(0)

                elif op == Op.GETITEM:
                    idxv = self.stack.pop()
                    target = self.stack.pop()
                    try:
                        if isinstance(target, list):
                            i2 = int(idxv)
                            self.stack.append(target[i2] if 0 <= i2 < len(target) else None)
                        elif isinstance(target, dict):
                            self.stack.append(target.get(idxv, None))
                        elif isinstance(target, str):
                            i2 = int(idxv)
                            self.stack.append(target[i2] if 0 <= i2 < len(target) else '')
                        elif isinstance(target, MellowLangRange):
                            i2 = int(idxv)
                            self.stack.append(target[i2] if 0 <= i2 < len(target) else None)
                        elif hasattr(target, "__getitem__"):
                            # safe-ish fallback
                            i2 = int(idxv) if isinstance(idxv, (int, float, bool)) or (isinstance(idxv, str) and idxv.isdigit()) else idxv
                            try:
                                self.stack.append(target[i2])
                            except Exception:
                                self.stack.append(None)
                        else:
                            self.stack.append(None)
                    except Exception:
                        self.stack.append(None)

                elif op == Op.BUILD_LIST:
                    n = int(instr[1])
                    items = []
                    for _ in range(n):
                        items.append(self.stack.pop() if self.stack else None)
                    items.reverse()
                    self._enforce_value_limits(items)
                    self.stack.append(items)

                elif op == Op.BUILD_MAP:
                    n = int(instr[1])
                    d = {}
                    for _ in range(n):
                        val = self.stack.pop() if self.stack else None
                        key = self.stack.pop() if self.stack else None
                        if not isinstance(key, str):
                            key = str(key)
                        d[key] = val
                    self._enforce_value_limits(d)
                    self.stack.append(d)

                elif op == Op.JUMP:
                    self.pc = instr[1]
                    continue

                elif op == Op.JIF:
                    cond = self.stack.pop() if self.stack else False
                    if not self._truthy(cond):
                        self.pc = instr[1]
                        continue

                elif op == Op.CALL:
                    f_name = instr[1]
                    argc = int(instr[2]) if len(instr) > 2 else 0
                    if f_name in self.func_table:
                        pcount = int(self.func_table[f_name].get('param_count', 0))
                        if argc > pcount:
                            self._raise_sandbox(f"too many args for {f_name} (got {argc}, want {pcount})")
                        for _ in range(pcount - argc):
                            self.stack.append(None)

                        # push return address + frame info
                        call_line, call_col = self._pos()
                        self.call_stack.append(self.pc + 1)
                        self.frame_stack.append({
                            "name": f_name,
                            "filename": self.filename,
                            "line": call_line,
                            "col": call_col,
                        })
                        self.variables.append({})
                        self.pc = int(self.func_table[f_name]['address'])
                        continue
                    self._raise_runtime(f"Unknown skill: {f_name}")

                elif op == Op.RETURN:
                    res = self.stack.pop() if self.stack else None
                    if self.variables:
                        self.variables.pop()
                    self.pc = self.call_stack.pop() if self.call_stack else len(self.bytecode)
                    if self.frame_stack:
                        self.frame_stack.pop()
                    self.stack.append(res)
                    continue

                elif op == Op.ARG:
                    self.variables[-1][instr[1]] = self.stack.pop() if self.stack else None

                elif op == Op.ASK:
                    if not self.config.get('allow_ask', False):
                        self._raise_sandbox('ask() is disabled')
                    prompt = self.stack.pop() if self.stack else ''
                    raw = input(str(prompt))
                    if raw.lower() == 'true': val = True
                    elif raw.lower() == 'false': val = False
                    else:
                        try:
                            val = float(raw) if '.' in raw else int(raw)
                        except ValueError:
                            val = raw
                    self._enforce_value_limits(val)
                    self.stack.append(val)

                elif op == Op.RANDOM:
                    high = int(self.stack.pop())
                    low = int(self.stack.pop())
                    result = self.rng.randint(low, high)
                    if self._replay.cfg.mode == 'replay':
                        result = self._replay.next_random_result(low, high)
                    else:
                        self._replay.record_random(low, high, result)
                    self.stack.append(result)

                elif op == Op.RANDFLOAT:
                    result = float(self.rng.random())
                    if self._replay.cfg.mode == 'replay':
                        result = self._replay.next_randfloat()
                    else:
                        self._replay.record_randfloat(result)
                    self.stack.append(result)

                elif op == Op.WAIT:
                    if not self.config.get('allow_wait', True):
                        self._raise_sandbox('wait() is disabled')
                    seconds = self.stack.pop()
                    try:
                        import time
                        time.sleep(float(seconds))
                    except Exception:
                        pass

                elif op == Op.SAVE_VAL:
                    value = self.stack.pop() if self.stack else None
                    filename = self.stack.pop() if self.stack else ''
                    self._save_json(filename, value)

                elif op == Op.SAVE:
                    filename = self.stack.pop() if self.stack else ''
                    var_name = instr[1]
                    self._save_json(filename, self._load_var(var_name))

                elif op == Op.LOAD_F:
                    filename = self.stack.pop() if self.stack else ''
                    var_name = instr[1]
                    self.variables[-1][var_name] = self._load_json(filename)

                elif op == Op.LIST_HAS:
                    item = self.stack.pop() if self.stack else None
                    target_list = self.stack.pop() if self.stack else []
                    self.stack.append(item in target_list if isinstance(target_list, list) else False)

                elif op == Op.LIST_PUT:
                    target_list = self.stack.pop() if self.stack else []
                    item = self.stack.pop() if self.stack else None
                    if not isinstance(target_list, list):
                        self._raise_runtime('put target is not a list')
                    target_list.append(item)
                    self._enforce_value_limits(target_list)

                elif op == Op.POP:
                    if self.stack:
                        self.stack.pop()

                elif op == Op.SYSCALL:
                    argc = int(instr[1]) if len(instr) > 1 else 0
                    args = []
                    for _ in range(argc):
                        args.append(self.stack.pop() if self.stack else None)
                    args.reverse()
                    name = self.stack.pop() if self.stack else ''
                    res = self._syscall(name, args)
                    self.stack.append(res)

                else:
                    self._raise_runtime(f'Unknown opcode: {op}')

                self.pc += 1
            except Exception as e:
                # record crash in replay? (optional)
                if self._handle_exception(e):
                    continue
                raise

        # persist keep vars (disabled by default)
        if self._keep_enabled and self._keep_dirty and self.config.get("persist_keep", False):
            try:
                key = (self.filename or "<memory>")
                self._save_json(f"__keep__{key}", self._keep_values)
                self._keep_dirty = False
            except Exception:
                pass
